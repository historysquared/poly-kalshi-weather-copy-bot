import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getOpenPositions,
  getClosedPositions,
  getActiveTrackedTraders,
  getRecentTraderTrades,
  addTrackedTrader,
  removeTrackedTrader,
  getSetting,
  setSetting,
  getRecentBotLogs,
  createPosition,
} from "./db";
import { sendTelegramMessage, alertOpportunity, testTelegramConnection } from "./telegram";
import { runCopyTradingCycle, getCopyTradeHistory, getTraderProfile } from "./copyTrader";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Trading data router
  trading: router({
    // Get portfolio data from database
    getPortfolio: publicProcedure.query(async () => {
      try {
        const openPositions = await getOpenPositions();
        const closedPositions = await getClosedPositions();

        // Calculate portfolio metrics
        const totalInvested = openPositions.reduce((sum, pos) => sum + parseFloat(pos.totalCost), 0);
        const totalPnl = closedPositions.reduce((sum, pos) => sum + parseFloat(pos.pnl || "0"), 0);
        const winCount = closedPositions.filter(pos => parseFloat(pos.pnl || "0") > 0).length;
        const lossCount = closedPositions.filter(pos => parseFloat(pos.pnl || "0") < 0).length;

        return {
          starting_capital: 1000.00,
          current_capital: 1000.00 - totalInvested + totalPnl,
          total_invested: totalInvested,
          total_pnl: totalPnl,
          open_positions: openPositions.map(pos => ({
            trade_id: pos.tradeId,
            market_id: pos.marketId,
            market_question: pos.marketQuestion,
            outcome: pos.outcome,
            shares: parseFloat(pos.shares),
            price: parseFloat(pos.entryPrice),
            total_cost: parseFloat(pos.totalCost),
            strategy_name: pos.strategyName,
            timestamp: pos.openedAt.toISOString(),
            notes: pos.notes || "",
          })),
          closed_positions: closedPositions.map(pos => ({
            trade_id: pos.tradeId,
            market_id: pos.marketId,
            market_question: pos.marketQuestion,
            outcome: pos.outcome,
            shares: parseFloat(pos.shares),
            entry_price: parseFloat(pos.entryPrice),
            exit_price: parseFloat(pos.exitPrice || "0"),
            pnl: parseFloat(pos.pnl || "0"),
            roi: parseFloat(pos.roi || "0"),
            strategy_name: pos.strategyName,
            opened_at: pos.openedAt.toISOString(),
            closed_at: pos.closedAt?.toISOString() || "",
          })),
          win_count: winCount,
          loss_count: lossCount,
          total_trades: closedPositions.length,
        };
      } catch (error) {
        console.error("[Trading API] Failed to read portfolio:", error);
        throw new Error("Failed to load portfolio data");
      }
    }),

    // Get tracked traders data from database
    getTrackedTraders: publicProcedure.query(async () => {
      try {
        const traders = await getActiveTrackedTraders();

        // Get recent trades for each trader
        const tradersWithTrades = await Promise.all(
          traders.map(async (trader) => {
            const recentTrades = await getRecentTraderTrades(trader.id, 5);

            return {
              username: trader.username,
              profile_url: trader.profileUrl,
              focus: trader.focus || "",
              notes: trader.notes || "",
              added_date: trader.addedAt.toISOString(),
              recent_trades: recentTrades.map(t => ({
                timestamp: t.detectedAt.toISOString(),
                type: 'Trade',
                market: (t.tradeData as any)?.market || 'Unknown market'
              }))
            };
          })
        );

        return tradersWithTrades;
      } catch (error) {
        console.error("[Trading API] Failed to read traders:", error);
        return [];
      }
    }),

    // Add a new tracked trader
    addTrader: protectedProcedure
      .input(z.object({
        username: z.string(),
        profileUrl: z.string().url(),
        focus: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await addTrackedTrader({
          username: input.username,
          profileUrl: input.profileUrl,
          focus: input.focus,
          notes: input.notes,
        });

        return { success: true };
      }),

    // Remove a tracked trader
    removeTrader: protectedProcedure
      .input(z.object({
        username: z.string(),
      }))
      .mutation(async ({ input }) => {
        await removeTrackedTrader(input.username);
        return { success: true };
      }),

    // Get bot logs
    getLogs: protectedProcedure
      .input(z.object({
        limit: z.number().optional().default(100),
      }))
      .query(async ({ input }) => {
        const logs = await getRecentBotLogs(input.limit);
        return logs.map(log => ({
          id: log.id,
          type: log.logType,
          message: log.message,
          data: log.data,
          timestamp: log.createdAt.toISOString(),
        }));
      }),

    // Get all trader trades for Live Trades view
    getAllTraderTrades: publicProcedure.query(async () => {
      const traders = await getActiveTrackedTraders();
      const allTrades: any[] = [];

      for (const trader of traders) {
        const trades = await getRecentTraderTrades(trader.id, 20);
        
        for (const trade of trades) {
          const tradeData = trade.tradeData as any;
          allTrades.push({
            id: trade.id,
            trader: trader.username,
            market: tradeData.market || 'Unknown market',
            outcome: tradeData.outcome || 'Unknown',
            side: tradeData.side || 'BUY',
            price: parseFloat(tradeData.price || '0'),
            size: parseFloat(tradeData.size || '0'),
            timestamp: trade.detectedAt.toISOString(),
          });
        }
      }

      // Sort by timestamp descending (newest first)
      allTrades.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      return allTrades;
    }),
  }),

  // Settings router
  settings: router({
    // Get Discord webhook URL
    getDiscordWebhook: protectedProcedure.query(async () => {
      const setting = await getSetting("discord_webhook_url");
      return { webhook_url: setting?.value || "" };
    }),

    // Set Discord webhook URL
    setDiscordWebhook: protectedProcedure
      .input(z.object({
        webhookUrl: z.string().url(),
      }))
      .mutation(async ({ input }) => {
        await setSetting("discord_webhook_url", input.webhookUrl, "Discord webhook URL for notifications");
        return { success: true };
      }),

    // Get bot settings
    getBotSettings: protectedProcedure.query(async () => {
      const scanInterval = await getSetting("bot_scan_interval");
      const isRunning = await getSetting("bot_is_running");

      return {
        scan_interval: parseInt(scanInterval?.value || "120"),
        is_running: isRunning?.value === "true",
      };
    }),

    // Update bot settings
    updateBotSettings: protectedProcedure
      .input(z.object({
        scanInterval: z.number().optional(),
        isRunning: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        if (input.scanInterval !== undefined) {
          await setSetting("bot_scan_interval", input.scanInterval.toString(), "Bot scan interval in seconds");
        }
        if (input.isRunning !== undefined) {
          await setSetting("bot_is_running", input.isRunning.toString(), "Bot running status");
        }
        return { success: true };
      }),
  }),

  // Kalshi live markets router
  kalshi: router({
    // Get live Kalshi weather markets with prices
    getWeatherMarkets: publicProcedure
      .input(z.object({ city: z.string().optional() }).optional())
      .query(async ({ input }) => {
        try {
          const city = input?.city || 'NYC';
          const resp = await fetch(
            `https://api.elections.kalshi.com/trade-api/v2/markets?series_ticker=KXHIGH${city === 'NYC' ? 'NY' : city.toUpperCase()}&status=open&limit=20`,
            { headers: { 'Accept': 'application/json' } }
          );
          if (!resp.ok) throw new Error(`Kalshi API error: ${resp.status}`);
          const data = await resp.json() as any;
          const markets = (data.markets || []).map((m: any) => ({
            ticker: m.ticker,
            title: m.title,
            // Kalshi API returns prices as dollar strings in *_dollars fields
            yes_ask: m.yes_ask_dollars !== undefined ? parseFloat(m.yes_ask_dollars) : null,
            yes_bid: m.yes_bid_dollars !== undefined ? parseFloat(m.yes_bid_dollars) : null,
            no_ask: m.no_ask_dollars !== undefined ? parseFloat(m.no_ask_dollars) : null,
            no_bid: m.no_bid_dollars !== undefined ? parseFloat(m.no_bid_dollars) : null,
            volume: parseFloat(m.volume_fp || m.volume_24h_fp || '0'),
            last_price: m.last_price_dollars ? parseFloat(m.last_price_dollars) : null,
            close_time: m.close_time,
            status: m.status,
          }));
          return { city, markets, timestamp: new Date().toISOString() };
        } catch (error) {
          console.error('[Kalshi API] Failed:', error);
          return { city: input?.city || 'NYC', markets: [], timestamp: new Date().toISOString() };
        }
      }),

    // Get all available cities
    getCities: publicProcedure.query(async () => {
      return [
        { id: 'NYC', name: 'New York City', ticker_prefix: 'KXHIGHNY' },
        { id: 'LA', name: 'Los Angeles', ticker_prefix: 'KXHIGHLAX' },
        { id: 'Chicago', name: 'Chicago', ticker_prefix: 'KXHIGHCHI' },
        { id: 'Miami', name: 'Miami', ticker_prefix: 'KXHIGHMIAMI' },
        { id: 'Dallas', name: 'Dallas', ticker_prefix: 'KXHIGHDAL' },
        { id: 'Seattle', name: 'Seattle', ticker_prefix: 'KXHIGHSEA' },
        { id: 'Atlanta', name: 'Atlanta', ticker_prefix: 'KXHIGHATL' },
        { id: 'Boston', name: 'Boston', ticker_prefix: 'KXHIGHBOS' },
      ];
    }),
  }),

  // Arbitrage scanner router
  arbitrage: router({
    // Get latest arbitrage scan results from file
    getLatestOpportunities: publicProcedure.query(async () => {
      try {
        const fs = await import('fs/promises');
        const path = await import('path');
        const reportPath = path.join(process.env.HOME || '/home/ubuntu', 'kalshi_bot/reports/arbitrage_opportunities.json');
        const content = await fs.readFile(reportPath, 'utf-8');
        return JSON.parse(content);
      } catch (error) {
        return {
          scan_time: new Date().toISOString(),
          total_opportunities: 0,
          opportunities: [],
          message: 'No scan data yet. Run the arbitrage scanner to populate.',
        };
      }
    }),

    // Get Kalshi paper trading portfolio
    getKalshiPortfolio: publicProcedure.query(async () => {
      try {
        const fs = await import('fs/promises');
        const path = await import('path');
        const portfolioPath = path.join(process.env.HOME || '/home/ubuntu', 'kalshi_bot/reports/kalshi_portfolio.json');
        const content = await fs.readFile(portfolioPath, 'utf-8');
        return JSON.parse(content);
      } catch (error) {
        return {
          exchange: 'kalshi',
          starting_capital: 1000.00,
          current_capital: 1000.00,
          total_pnl: 0,
          open_positions: [],
          total_trades: 0,
          message: 'No Kalshi paper trading data yet.',
        };
      }
    }),
  }),

  // Telegram notification router
  telegram: router({
    // Test Telegram connection
    test: protectedProcedure.mutation(async () => {
      const ok = await testTelegramConnection();
      return { success: ok, message: ok ? "Telegram connected! Check your phone." : "Failed to connect. Check your bot token and chat ID." };
    }),

    // Send a custom message
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string() }))
      .mutation(async ({ input }) => {
        const ok = await sendTelegramMessage(input.message);
        return { success: ok };
      }),

    // Get Telegram settings
    getSettings: protectedProcedure.query(async () => {
      const token = process.env.TELEGRAM_BOT_TOKEN || "";
      const chatId = process.env.TELEGRAM_CHAT_ID || "";
      return {
        configured: !!(token && chatId),
        botName: token ? "@WeatherTrader1_bot" : "",
        chatId: chatId ? chatId.slice(0, 4) + "****" : "",
      };
    }),
  }),

  // Copy trading router
  copyTrading: router({
    // Run one copy trading cycle manually
    runCycle: protectedProcedure.mutation(async () => {
      const result = await runCopyTradingCycle();
      return result;
    }),

    // Get copy trade history
    getHistory: publicProcedure
      .input(z.object({ limit: z.number().optional().default(50) }))
      .query(async ({ input }) => {
        const trades = await getCopyTradeHistory(input.limit);
        return trades.map(t => ({
          id: t.id,
          traderName: t.traderName,
          originalMarket: t.originalMarket,
          originalSide: t.originalSide,
          kalshiTicker: t.kalshiTicker,
          kalshiSide: t.kalshiSide,
          price: parseFloat(t.price),
          amount: parseFloat(t.amount),
          shares: parseFloat(t.shares),
          status: t.status,
          paperMode: t.paperMode,
          pnl: t.pnl ? parseFloat(t.pnl) : null,
          createdAt: t.createdAt.toISOString(),
        }));
      }),

    // Get full trader profile: active positions + closed positions + recent trades
    getTraderProfile: publicProcedure
      .input(z.object({ walletAddress: z.string() }))
      .query(async ({ input }) => {
        return await getTraderProfile(input.walletAddress);
      }),
  }),

  // Bot control endpoints
  bot: router({
    start: publicProcedure
      .input(z.object({ intervalSeconds: z.number().min(10).default(30) }).optional())
      .mutation(async ({ input }) => {
        const { tradingBotService } = await import('./botService');
        await tradingBotService.start(input?.intervalSeconds || 30);
        return { success: true, message: 'Bot started' };
      }),
    
    stop: publicProcedure
      .mutation(async () => {
        const { tradingBotService } = await import('./botService');
        await tradingBotService.stop();
        return { success: true, message: 'Bot stopped' };
      }),
    
    status: publicProcedure
      .query(async () => {
        const { tradingBotService } = await import('./botService');
        return tradingBotService.getStatus();
      }),
  }),
});

export type AppRouter = typeof appRouter;

// Auto-start bot on server startup
if (process.env.NODE_ENV === 'production') {
  import('./botService').then(({ tradingBotService }) => {
    tradingBotService.start(30).catch(console.error); // 30s scan interval
  });
}
