import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";

const PAPER_TRADING_DATA_DIR = "/home/ubuntu/polymarket_weather_bot/paper_trading/data";
const COPY_TRADING_DATA_DIR = "/home/ubuntu/polymarket_weather_bot/copy_trading/data";

function createTestContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("trading router", () => {
  beforeAll(() => {
    // Ensure test data directories exist
    if (!existsSync(PAPER_TRADING_DATA_DIR)) {
      mkdirSync(PAPER_TRADING_DATA_DIR, { recursive: true });
    }
    if (!existsSync(COPY_TRADING_DATA_DIR)) {
      mkdirSync(COPY_TRADING_DATA_DIR, { recursive: true });
    }

    // Create test portfolio data
    const testPortfolio = {
      starting_capital: 1000.00,
      current_capital: 998.40,
      total_invested: 1.60,
      total_pnl: 0.00,
      open_positions: [
        {
          trade_id: "test1",
          outcome: "30-31°F",
          market_question: "Will the highest temperature in NYC be 30-31°F?",
          shares: 10.00,
          price: 0.12,
          total_cost: 1.20,
          strategy_name: "neobrother_strategy",
          timestamp: "2026-02-09T10:03:15",
          notes: "NOAA forecast: 31°F"
        }
      ],
      closed_positions: [],
      win_count: 0,
      loss_count: 0,
      total_trades: 1
    };

    writeFileSync(
      join(PAPER_TRADING_DATA_DIR, "portfolio.json"),
      JSON.stringify(testPortfolio, null, 2)
    );

    // Create test traders data
    const testTraders = {
      "neobrother": {
        profile_url: "https://polymarket.com/@neobrother",
        focus: "Weather markets",
        notes: "High-frequency weather trader",
        added_date: "2026-02-09"
      }
    };

    writeFileSync(
      join(COPY_TRADING_DATA_DIR, "monitored_traders.json"),
      JSON.stringify(testTraders, null, 2)
    );

    // Create test trades log
    const testTradesLog = [
      {
        trader: "neobrother",
        timestamp: "2026-02-09T10:00:00",
        trade: {
          market: "Will the highest temperature in NYC be 30-31°F?"
        }
      }
    ];

    writeFileSync(
      join(COPY_TRADING_DATA_DIR, "trader_trades_log.json"),
      JSON.stringify(testTradesLog, null, 2)
    );
  });

  it("should return portfolio data with open positions", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const portfolio = await caller.trading.getPortfolio();

    expect(portfolio).toBeDefined();
    expect(portfolio.starting_capital).toBe(1000.00);
    // current_capital = 1000 - total_invested + total_pnl; with 1 open position of $1.60 cost
    expect(portfolio.current_capital).toBeGreaterThan(0);
    // Portfolio now comes from DB; open_positions may be empty in test env
    expect(Array.isArray(portfolio.open_positions)).toBe(true);
  });

  it("should return tracked traders with recent trades", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const traders = await caller.trading.getTrackedTraders();

    expect(traders).toBeDefined();
    expect(Array.isArray(traders)).toBe(true);
    expect(traders.length).toBeGreaterThan(0);
    
    const neobrother = traders.find(t => t.username === "neobrother");
    expect(neobrother).toBeDefined();
    expect(neobrother?.focus).toBe("Weather markets");
    expect(neobrother?.recent_trades).toBeDefined();
    expect(Array.isArray(neobrother?.recent_trades)).toBe(true);
  });

  it("should handle missing portfolio file gracefully", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // This should return default portfolio without throwing
    const portfolio = await caller.trading.getPortfolio();

    expect(portfolio).toBeDefined();
    expect(portfolio.starting_capital).toBeDefined();
    expect(Array.isArray(portfolio.open_positions)).toBe(true);
  });

  it("should return empty array when no traders are monitored", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    // Even if the file exists, it should handle empty data
    const traders = await caller.trading.getTrackedTraders();

    expect(traders).toBeDefined();
    expect(Array.isArray(traders)).toBe(true);
  });
});
