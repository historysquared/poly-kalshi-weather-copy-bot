import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, positions, trackedTraders, traderTrades, settings, botLogs, InsertPosition, InsertTrackedTrader, InsertTraderTrade, InsertSetting, InsertBotLog } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Trading System Database Helpers

/**
 * Get all open positions
 */
export async function getOpenPositions() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(positions).where(eq(positions.status, "open")).orderBy(desc(positions.openedAt));
}

/**
 * Get all closed positions
 */
export async function getClosedPositions() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(positions).where(eq(positions.status, "closed")).orderBy(desc(positions.closedAt));
}

/**
 * Create a new position
 */
export async function createPosition(position: InsertPosition) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(positions).values(position);
  return result;
}

/**
 * Close a position
 */
export async function closePosition(tradeId: string, exitPrice: string, pnl: string, roi: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(positions)
    .set({ 
      status: "closed", 
      exitPrice, 
      pnl, 
      roi, 
      closedAt: new Date() 
    })
    .where(eq(positions.tradeId, tradeId));
}

/**
 * Get all active tracked traders
 */
export async function getActiveTrackedTraders() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(trackedTraders).where(eq(trackedTraders.isActive, true));
}

/**
 * Add a tracked trader
 */
export async function addTrackedTrader(trader: InsertTrackedTrader) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(trackedTraders).values(trader);
  return result;
}

/**
 * Remove a tracked trader
 */
export async function removeTrackedTrader(username: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(trackedTraders)
    .set({ isActive: false })
    .where(eq(trackedTraders.username, username));
}

/**
 * Log trader trade activity
 */
export async function logTraderTrade(trade: InsertTraderTrade) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(traderTrades).values(trade);
}

/**
 * Get recent trader trades
 */
export async function getRecentTraderTrades(traderId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(traderTrades)
    .where(eq(traderTrades.traderId, traderId))
    .orderBy(desc(traderTrades.detectedAt))
    .limit(limit);
}

/**
 * Get a setting by key
 */
export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return result.length > 0 ? result[0] : null;
}

/**
 * Set a setting
 */
export async function setSetting(key: string, value: string, description?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(settings)
    .values({ key, value, description })
    .onDuplicateKeyUpdate({ set: { value, updatedAt: new Date() } });
}

/**
 * Log bot activity
 */
export async function logBotActivity(log: InsertBotLog) {
  const db = await getDb();
  if (!db) return;
  
  await db.insert(botLogs).values(log);
}

/**
 * Get recent bot logs
 */
export async function getRecentBotLogs(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(botLogs)
    .orderBy(desc(botLogs.createdAt))
    .limit(limit);
}
