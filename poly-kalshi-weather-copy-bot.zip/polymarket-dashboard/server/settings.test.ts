import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { setSetting, getSetting } from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("settings router", () => {
  it("gets Discord webhook setting", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Set a test webhook
    await setSetting("discord_webhook_url", "https://discord.com/api/webhooks/test", "Test webhook");

    const result = await caller.settings.getDiscordWebhook();

    expect(result).toHaveProperty("webhook_url");
    expect(result.webhook_url).toBe("https://discord.com/api/webhooks/test");
  });

  it("sets Discord webhook setting", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.setDiscordWebhook({
      webhookUrl: "https://discord.com/api/webhooks/new-test",
    });

    expect(result).toEqual({ success: true });

    // Verify it was saved
    const saved = await getSetting("discord_webhook_url");
    expect(saved?.value).toBe("https://discord.com/api/webhooks/new-test");
  });

  it("gets bot settings", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Set test bot settings
    await setSetting("bot_scan_interval", "180", "Scan interval");
    await setSetting("bot_is_running", "true", "Bot status");

    const result = await caller.settings.getBotSettings();

    expect(result).toHaveProperty("scan_interval");
    expect(result).toHaveProperty("is_running");
    expect(result.scan_interval).toBe(180);
    expect(result.is_running).toBe(true);
  });

  it("updates bot settings", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.settings.updateBotSettings({
      scanInterval: 240,
      isRunning: false,
    });

    expect(result).toEqual({ success: true });

    // Verify settings were updated
    const interval = await getSetting("bot_scan_interval");
    const running = await getSetting("bot_is_running");
    expect(interval?.value).toBe("240");
    expect(running?.value).toBe("false");
  });
});
