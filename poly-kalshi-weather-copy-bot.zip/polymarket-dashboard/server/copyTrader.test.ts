/**
 * Tests for the Kalshi Copy Trading Engine
 * Covers: market mapping, slippage guard, wallet address extraction,
 *         API fetching, and deduplication logic
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

// Mock telegram
vi.mock("./telegram", () => ({
  alertCopyTradeExecuted: vi.fn().mockResolvedValue(true),
}));

import {
  MARKET_MAPPING,
  COPY_TRADE_AMOUNT,
  MAX_SLIPPAGE_PCT,
  isWithinSlippage,
  findKalshiEquivalent,
  fetchPolymarketPositions,
  fetchPolymarketTrades,
  getTraderProfile,
  runCopyTradingCycle,
  getCopyTradeHistory,
  SCAN_INTERVAL_MS,
} from "./copyTrader";

// ─── Constants ────────────────────────────────────────────────────────────────

describe("constants", () => {
  it("COPY_TRADE_AMOUNT is exactly $5", () => {
    expect(COPY_TRADE_AMOUNT).toBe(5.00);
  });

  it("MAX_SLIPPAGE_PCT is 20%", () => {
    expect(MAX_SLIPPAGE_PCT).toBe(0.20);
  });

  it("SCAN_INTERVAL_MS is 30 seconds", () => {
    expect(SCAN_INTERVAL_MS).toBe(30_000);
  });
});

// ─── Market Mapping ───────────────────────────────────────────────────────────

describe("MARKET_MAPPING", () => {
  it("maps all expected cities to Kalshi tickers", () => {
    expect(MARKET_MAPPING["NYC"]).toBe("KXHIGHNY");
    expect(MARKET_MAPPING["New York"]).toBe("KXHIGHNY");
    expect(MARKET_MAPPING["Chicago"]).toBe("KXHIGHCHI");
    expect(MARKET_MAPPING["Los Angeles"]).toBe("KXHIGHLAX");
    expect(MARKET_MAPPING["LA"]).toBe("KXHIGHLAX");
    expect(MARKET_MAPPING["Dallas"]).toBe("KXHIGHDAL");
    expect(MARKET_MAPPING["Miami"]).toBe("KXHIGHMIAMI");
    expect(MARKET_MAPPING["Atlanta"]).toBe("KXHIGHATLANTA");
    expect(MARKET_MAPPING["Seattle"]).toBe("KXHIGHSEATTLE");
    expect(MARKET_MAPPING["Boston"]).toBe("KXHIGHBOSTON");
  });

  it("word-boundary regex: 'Dallas' does NOT match 'LA' keyword", () => {
    const keyword = "LA";
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`\\b${escaped}\\b`, "i");
    expect(pattern.test("High temp in Dallas TX tomorrow")).toBe(false);
    expect(pattern.test("LA weather forecast")).toBe(true);
    expect(pattern.test("Los Angeles high temp")).toBe(false); // "LA" not a standalone word here
  });

  it("matches all test cases correctly with word-boundary logic", () => {
    const testCases = [
      { market: "Will NYC high be >50°F?", expected: "KXHIGHNY" },
      { market: "New York temperature tomorrow", expected: "KXHIGHNY" },
      { market: "Chicago high temperature", expected: "KXHIGHCHI" },
      { market: "LA weather forecast", expected: "KXHIGHLAX" },
      { market: "High temp in Dallas TX tomorrow", expected: "KXHIGHDAL" },
      { market: "Miami heat index", expected: "KXHIGHMIAMI" },
      { market: "Atlanta high above 60°F?", expected: "KXHIGHATLANTA" },
    ];

    for (const tc of testCases) {
      let found = "";
      for (const [keyword, ticker] of Object.entries(MARKET_MAPPING)) {
        const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const pattern = new RegExp(`\\b${escaped}\\b`, "i");
        if (pattern.test(tc.market)) {
          found = ticker;
          break;
        }
      }
      expect(found, `Market: "${tc.market}"`).toBe(tc.expected);
    }
  });

  it("returns empty string for non-weather markets", () => {
    let found = "";
    const market = "Will Bitcoin reach $100k?";
    for (const [keyword, ticker] of Object.entries(MARKET_MAPPING)) {
      const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const pattern = new RegExp(`\\b${escaped}\\b`, "i");
      if (pattern.test(market)) {
        found = ticker;
        break;
      }
    }
    expect(found).toBe("");
  });
});

// ─── Slippage Guard ───────────────────────────────────────────────────────────

describe("isWithinSlippage", () => {
  describe("YES side", () => {
    it("allows trade when Kalshi ask equals original price", () => {
      expect(isWithinSlippage(0.12, 0.12, "yes")).toBe(true);
    });

    it("allows trade when Kalshi ask is 10% higher (within 20% limit)", () => {
      // orig=0.12, kalshi=0.132 → slippage=10%
      expect(isWithinSlippage(0.12, 0.132, "yes")).toBe(true);
    });

    it("allows trade exactly at the 20% boundary", () => {
      // orig=0.12, kalshi=0.144 → slippage=20%
      expect(isWithinSlippage(0.12, 0.144, "yes")).toBe(true);
    });

    it("rejects trade when Kalshi ask is 50% higher", () => {
      // orig=0.12, kalshi=0.18 → slippage=50%
      expect(isWithinSlippage(0.12, 0.18, "yes")).toBe(false);
    });

    it("rejects trade when Kalshi ask is 21% higher", () => {
      // orig=0.12, kalshi=0.1452 → slippage=21%
      expect(isWithinSlippage(0.12, 0.1452, "yes")).toBe(false);
    });

    it("allows trade when Kalshi ask is lower than original (favorable)", () => {
      expect(isWithinSlippage(0.50, 0.45, "yes")).toBe(true);
    });
  });

  describe("NO side", () => {
    it("uses (1 - originalPrice) as reference for NO trades", () => {
      // orig=0.80 YES → NO reference = 0.20
      // kalshi NO ask = 0.22 → slippage = (0.22-0.20)/0.20 = 10% → OK
      expect(isWithinSlippage(0.80, 0.22, "no")).toBe(true);
    });

    it("rejects NO trade with excessive slippage", () => {
      // orig=0.80 YES → NO reference = 0.20
      // kalshi NO ask = 0.30 → slippage = 50% → reject
      expect(isWithinSlippage(0.80, 0.30, "no")).toBe(false);
    });
  });

  describe("edge cases", () => {
    it("allows trade when originalPrice is 0 (can't evaluate)", () => {
      expect(isWithinSlippage(0, 0.15, "yes")).toBe(true);
    });

    it("allows trade when kalshiAsk is 0 (can't evaluate)", () => {
      expect(isWithinSlippage(0.15, 0, "yes")).toBe(true);
    });

    it("respects custom maxSlippagePct override", () => {
      // 5% limit: orig=0.12, kalshi=0.13 → slippage=8.3% → reject
      expect(isWithinSlippage(0.12, 0.13, "yes", 0.05)).toBe(false);
      // 5% limit: orig=0.12, kalshi=0.1255 → slippage=4.6% → allow
      expect(isWithinSlippage(0.12, 0.1255, "yes", 0.05)).toBe(true);
    });
  });
});

// ─── findKalshiEquivalent ─────────────────────────────────────────────────────

describe("findKalshiEquivalent", () => {
  beforeEach(() => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        markets: [
          {
            ticker: "KXHIGHDAL-25MAR18-T55",
            volume: 1000,
            yes_ask_dollars: "0.45",
            no_ask_dollars: "0.55",
          },
        ],
      }),
    }));
  });

  it("matches 'Dallas' without confusing it with 'LA'", async () => {
    const result = await findKalshiEquivalent(
      "Will the high temperature in Dallas TX be above 55°F?",
      "YES"
    );
    expect(result).not.toBeNull();
    const fetchCall = (fetch as any).mock.calls[0][0] as string;
    expect(fetchCall).toContain("KXHIGHDAL");
  });

  it("matches 'LA' in a title that doesn't contain Dallas", async () => {
    const result = await findKalshiEquivalent(
      "Will the high temperature in LA exceed 70°F?",
      "YES"
    );
    expect(result).not.toBeNull();
    const fetchCall = (fetch as any).mock.calls[0][0] as string;
    expect(fetchCall).toContain("KXHIGHLAX");
  });

  it("returns null for a market with no matching city", async () => {
    (fetch as any).mockResolvedValue({ ok: true, json: async () => ({ markets: [] }) });
    const result = await findKalshiEquivalent("Will it rain in Phoenix tomorrow?", "YES");
    expect(result).toBeNull();
  });

  it("returns YES side price from yes_ask_dollars", async () => {
    const result = await findKalshiEquivalent("NYC high temperature above 50°F?", "YES");
    expect(result?.kalshiSide).toBe("yes");
    expect(result?.price).toBe(0.45);
  });

  it("returns NO side price from no_ask_dollars", async () => {
    const result = await findKalshiEquivalent("NYC high temperature above 50°F?", "NO");
    expect(result?.kalshiSide).toBe("no");
    expect(result?.price).toBe(0.55);
  });

  it("returns null when Kalshi API returns error", async () => {
    (fetch as any).mockResolvedValue({ ok: false, status: 500 });
    const result = await findKalshiEquivalent("NYC high temperature above 50°F?", "YES");
    expect(result).toBeNull();
  });
});

// ─── Polymarket API Fetching ──────────────────────────────────────────────────

describe("fetchPolymarketPositions", () => {
  it("returns empty array on HTTP error", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 404 }));
    const result = await fetchPolymarketPositions("0xabc123");
    expect(result).toEqual([]);
  });

  it("returns array of positions on success", async () => {
    const mockPositions = [
      { title: "NYC high above 50°F?", outcome: "YES", size: 10, avgPrice: 0.12, curPrice: 0.15 },
      { title: "Chicago high above 40°F?", outcome: "NO", size: 5, avgPrice: 0.55, curPrice: 0.50 },
    ];
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => mockPositions,
    }));
    const result = await fetchPolymarketPositions("0x56687bf447db6ffa42ffe2204a05edaa20f55839");
    expect(result).toHaveLength(2);
    expect(result[0].title).toContain("NYC");
  });

  it("returns empty array on network error", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("Network error")));
    const result = await fetchPolymarketPositions("0xabc123");
    expect(result).toEqual([]);
  });
});

describe("fetchPolymarketTrades", () => {
  it("returns empty array on HTTP error", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 500 }));
    const result = await fetchPolymarketTrades("0xabc123");
    expect(result).toEqual([]);
  });

  it("returns array of trades on success", async () => {
    const mockTrades = [
      {
        transactionHash: "0xaaa",
        title: "Will NYC high exceed 55°F on March 20?",
        side: "BUY",
        outcome: "YES",
        price: "0.12",
        size: "41.67",
        timestamp: Date.now() - 60000,
      },
    ];
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => mockTrades,
    }));
    const result = await fetchPolymarketTrades("0x56687bf447db6ffa42ffe2204a05edaa20f55839");
    expect(result).toHaveLength(1);
    expect(result[0].side).toBe("BUY");
    expect(result[0].price).toBe("0.12");
  });

  it("returns empty array on network error", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("Timeout")));
    const result = await fetchPolymarketTrades("0xabc123");
    expect(result).toEqual([]);
  });
});

// ─── getTraderProfile ─────────────────────────────────────────────────────────

describe("getTraderProfile", () => {
  it("returns combined active positions, closed positions, and recent trades", async () => {
    let callCount = 0;
    vi.stubGlobal("fetch", vi.fn().mockImplementation(async (url: string) => {
      callCount++;
      if (url.includes("redeemable=true")) {
        return { ok: true, json: async () => [{ title: "Closed position", outcome: "YES" }] };
      }
      if (url.includes("/trades?")) {
        return { ok: true, json: async () => [{ transactionHash: "0xbbb", side: "BUY" }] };
      }
      // Default: active positions
      return { ok: true, json: async () => [{ title: "Active position", outcome: "NO" }] };
    }));

    const profile = await getTraderProfile("0x56687bf447db6ffa42ffe2204a05edaa20f55839");
    expect(profile.activePositions).toHaveLength(1);
    expect(profile.closedPositions).toHaveLength(1);
    expect(profile.recentTrades).toHaveLength(1);
    expect(callCount).toBe(3); // 3 parallel API calls
  });

  it("handles partial failures gracefully", async () => {
    vi.stubGlobal("fetch", vi.fn().mockImplementation(async (url: string) => {
      if (url.includes("/trades?")) {
        throw new Error("Trades API down");
      }
      return { ok: true, json: async () => [] };
    }));

    const profile = await getTraderProfile("0xabc123");
    expect(profile.activePositions).toEqual([]);
    expect(profile.closedPositions).toEqual([]);
    expect(profile.recentTrades).toEqual([]); // graceful empty on error
  });
});

// ─── runCopyTradingCycle ──────────────────────────────────────────────────────

describe("runCopyTradingCycle", () => {
  it("returns structured result when database is unavailable", async () => {
    const result = await runCopyTradingCycle();
    expect(result).toHaveProperty("checked");
    expect(result).toHaveProperty("copied");
    expect(result).toHaveProperty("skippedSlippage");
    expect(result).toHaveProperty("errors");
    expect(typeof result.checked).toBe("number");
    expect(typeof result.copied).toBe("number");
    expect(typeof result.skippedSlippage).toBe("number");
    expect(Array.isArray(result.errors)).toBe(true);
  });
});

// ─── getCopyTradeHistory ──────────────────────────────────────────────────────

describe("getCopyTradeHistory", () => {
  it("returns empty array when database is unavailable", async () => {
    const result = await getCopyTradeHistory(10);
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(0);
  });
});

// ─── Trade Deduplication ──────────────────────────────────────────────────────

describe("trade deduplication", () => {
  it("does not process the same transaction hash twice", () => {
    const seen = new Set<string>();
    const txHash = "0xabc123def456";

    const firstTime = !seen.has(txHash);
    seen.add(txHash);
    expect(firstTime).toBe(true);

    const secondTime = !seen.has(txHash);
    expect(secondTime).toBe(false);
  });

  it("filters out trades older than 5 minutes", () => {
    const sixMinutesAgo = Date.now() - 6 * 60 * 1000;
    const thirtySecondsAgo = Date.now() - 30 * 1000;
    const TRADE_AGE_LIMIT_MS = 5 * 60 * 1000;

    const isOld = (ts: number) => Date.now() - ts > TRADE_AGE_LIMIT_MS;

    expect(isOld(sixMinutesAgo)).toBe(true);
    expect(isOld(thirtySecondsAgo)).toBe(false);
  });

  it("handles timestamp in seconds (Polymarket uses seconds, not ms)", () => {
    // Some Polymarket timestamps are in seconds (10 digits), not ms (13 digits)
    const tsSeconds = Math.floor((Date.now() - 60_000) / 1000); // 1 minute ago in seconds
    const normalized = tsSeconds > 1e12 ? tsSeconds : tsSeconds * 1000;
    const age = Date.now() - normalized;
    expect(age).toBeGreaterThan(0);
    expect(age).toBeLessThan(5 * 60 * 1000); // within 5 minutes
  });
});
