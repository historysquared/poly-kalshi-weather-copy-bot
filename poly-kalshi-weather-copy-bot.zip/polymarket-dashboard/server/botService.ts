/**
 * Automated Trading Bot Service
 * Executes Python trading bot on a schedule and manages bot lifecycle
 */

import { spawn, ChildProcess } from 'child_process';
import { getDb } from './db';
import { botLogs } from '../drizzle/schema';

interface BotStatus {
  isRunning: boolean;
  lastRun: Date | null;
  nextRun: Date | null;
  scanCount: number;
  errorCount: number;
}

class TradingBotService {
  private intervalId: NodeJS.Timeout | null = null;
  private currentProcess: ChildProcess | null = null;
  private status: BotStatus = {
    isRunning: false,
    lastRun: null,
    nextRun: null,
    scanCount: 0,
    errorCount: 0,
  };
  private scanIntervalMs: number = 120000; // 2 minutes default

  constructor() {
    console.log('[BotService] Trading bot service initialized');
  }

  /**
   * Start the automated bot execution
   */
  async start(intervalSeconds: number = 120): Promise<void> {
    if (this.intervalId) {
      console.log('[BotService] Bot already running');
      return;
    }

    this.scanIntervalMs = intervalSeconds * 1000;
    console.log(`[BotService] Starting bot with ${intervalSeconds}s interval`);

    // Run immediately
    await this.executeBotScan();

    // Schedule recurring scans
    this.intervalId = setInterval(async () => {
      await this.executeBotScan();
    }, this.scanIntervalMs);

    this.status.isRunning = true;
    this.updateNextRunTime();

    await this.logActivity('bot_started', `Bot started with ${intervalSeconds}s scan interval`);
  }

  /**
   * Stop the automated bot execution
   */
  async stop(): Promise<void> {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    if (this.currentProcess) {
      this.currentProcess.kill();
      this.currentProcess = null;
    }

    this.status.isRunning = false;
    this.status.nextRun = null;

    console.log('[BotService] Bot stopped');
    await this.logActivity('bot_stopped', 'Bot execution stopped');
  }

  /**
   * Execute a single bot scan
   */
  private async executeBotScan(): Promise<void> {
    if (this.currentProcess) {
      console.log('[BotService] Previous scan still running, skipping...');
      return;
    }

    console.log(`[BotService] Starting scan #${this.status.scanCount + 1}`);
    const scanStart = Date.now();

    try {
      await this.runPythonBot();
      
      this.status.scanCount++;
      this.status.lastRun = new Date();
      this.updateNextRunTime();

      const duration = Date.now() - scanStart;
      console.log(`[BotService] Scan completed in ${duration}ms`);

      // Also monitor tracked traders
      const { monitorAllTrackedTraders } = await import('./traderMonitor');
      await monitorAllTrackedTraders();

      await this.logActivity('scan_complete', `Scan #${this.status.scanCount} completed`, {
        duration_ms: duration,
        scan_number: this.status.scanCount,
      });

    } catch (error) {
      this.status.errorCount++;
      console.error('[BotService] Scan failed:', error);

      await this.logActivity('scan_error', `Scan failed: ${error}`, {
        error: String(error),
        scan_number: this.status.scanCount + 1,
      });
    }
  }

  /**
   * Run the Python trading bot
   */
  private runPythonBot(): Promise<void> {
    return new Promise((resolve, reject) => {
      const botPath = '/home/ubuntu/polymarket_weather_bot/integrated_system_db.py';
      
      // Get database URL from environment
      const databaseUrl = process.env.DATABASE_URL;
      if (!databaseUrl) {
        reject(new Error('DATABASE_URL not configured'));
        return;
      }

      // Spawn Python process
      this.currentProcess = spawn('python3', [botPath, '--mode', 'once', '--database-url', databaseUrl], {
        env: {
          ...process.env,
          DATABASE_URL: databaseUrl,
          DISCORD_WEBHOOK_URL: process.env.DISCORD_WEBHOOK_URL || '',
        },
      });

      let stdout = '';
      let stderr = '';

      this.currentProcess.stdout?.on('data', (data) => {
        const output = data.toString();
        stdout += output;
        console.log('[Bot]', output.trim());
      });

      this.currentProcess.stderr?.on('data', (data) => {
        const output = data.toString();
        stderr += output;
        console.error('[Bot Error]', output.trim());
      });

      this.currentProcess.on('close', (code) => {
        this.currentProcess = null;

        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`Bot exited with code ${code}\nStderr: ${stderr}`));
        }
      });

      this.currentProcess.on('error', (error) => {
        this.currentProcess = null;
        reject(error);
      });
    });
  }

  /**
   * Get current bot status
   */
  getStatus(): BotStatus {
    return { ...this.status };
  }

  /**
   * Update next run time
   */
  private updateNextRunTime(): void {
    if (this.status.isRunning) {
      this.status.nextRun = new Date(Date.now() + this.scanIntervalMs);
    }
  }

  /**
   * Log bot activity to database
   */
  private async logActivity(type: string, message: string, data?: Record<string, unknown>): Promise<void> {
    try {
      const db = await getDb();
      if (!db) return;

      await db.insert(botLogs).values({
        logType: type as 'scan' | 'trade' | 'error' | 'notification',
        message,
        data: data ? JSON.stringify(data) : null,
        createdAt: new Date(),
      });
    } catch (error) {
      console.error('[BotService] Failed to log activity:', error);
    }
  }
}

// Singleton instance
export const tradingBotService = new TradingBotService();
