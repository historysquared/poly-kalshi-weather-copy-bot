/**
 * Trader Monitor Service
 * Fetches real trading activity from Polymarket for tracked traders
 */

import axios from 'axios';
import { getDb } from './db';
import { trackedTraders, traderTrades } from '../drizzle/schema';
import { eq } from 'drizzle-orm';

interface PolymarketTrade {
  id: string;
  market: string;
  outcome: string;
  side: 'BUY' | 'SELL';
  price: number;
  size: number;
  timestamp: number;
}

/**
 * Fetch recent trades for a specific trader from Polymarket
 */
export async function fetchTraderActivity(username: string): Promise<PolymarketTrade[]> {
  try {
    // Polymarket API endpoint for user trades
    // Note: This is a simplified example - actual API may require authentication
    const response = await axios.get(
      `https://gamma-api.polymarket.com/users/${username}/trades`,
      {
        params: {
          limit: 20,
        },
        timeout: 10000,
      }
    );

    return response.data.map((trade: any) => ({
      id: trade.id,
      market: trade.market_question || trade.market,
      outcome: trade.outcome,
      side: trade.side,
      price: parseFloat(trade.price),
      size: parseFloat(trade.size),
      timestamp: trade.timestamp || Date.now(),
    }));
  } catch (error) {
    console.error(`[TraderMonitor] Failed to fetch trades for ${username}:`, error);
    return [];
  }
}

/**
 * Update database with latest trader activity
 */
export async function updateTrackedTraderActivity(traderId: number, username: string): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  try {
    const trades = await fetchTraderActivity(username);
    
    if (trades.length === 0) {
      console.log(`[TraderMonitor] No new trades for ${username}`);
      return 0;
    }

    // Store trades in database
    let newTradesCount = 0;
    for (const trade of trades) {
      try {
        await db.insert(traderTrades).values({
          traderId,
          tradeData: JSON.stringify(trade),
          detectedAt: new Date(trade.timestamp),
          createdAt: new Date(),
        });
        newTradesCount++;
      } catch (error) {
        // Trade might already exist (duplicate key), skip
        continue;
      }
    }

    // Update last checked timestamp
    await db
      .update(trackedTraders)
      .set({ lastCheckedAt: new Date() })
      .where(eq(trackedTraders.id, traderId));

    console.log(`[TraderMonitor] Added ${newTradesCount} new trades for ${username}`);
    return newTradesCount;

  } catch (error) {
    console.error(`[TraderMonitor] Error updating trader activity:`, error);
    return 0;
  }
}

/**
 * Monitor all active tracked traders
 */
export async function monitorAllTrackedTraders(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    const traders = await db
      .select()
      .from(trackedTraders)
      .where(eq(trackedTraders.isActive, true));

    console.log(`[TraderMonitor] Monitoring ${traders.length} traders`);

    for (const trader of traders) {
      await updateTrackedTraderActivity(trader.id, trader.username);
      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

  } catch (error) {
    console.error('[TraderMonitor] Error monitoring traders:', error);
  }
}
