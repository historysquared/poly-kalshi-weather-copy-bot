/**
 * Telegram Notification Service
 * Sends real-time trade alerts to the user's Telegram chat
 */

const TELEGRAM_API = "https://api.telegram.org";

function getBotToken(): string | undefined {
  return process.env.TELEGRAM_BOT_TOKEN;
}

function getChatId(): string | undefined {
  return process.env.TELEGRAM_CHAT_ID;
}

async function sendMessage(text: string, parseMode: "Markdown" | "HTML" = "Markdown"): Promise<boolean> {
  const token = getBotToken();
  const chatId = getChatId();

  if (!token || !chatId) {
    console.warn("[Telegram] Bot token or chat ID not configured, skipping alert");
    return false;
  }

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: parseMode,
      }),
    });

    const data = await res.json() as { ok: boolean; description?: string };
    if (!data.ok) {
      console.error("[Telegram] API error:", data.description);
      return false;
    }
    return true;
  } catch (err) {
    console.error("[Telegram] Failed to send message:", err);
    return false;
  }
}

// ─── Alert Templates ─────────────────────────────────────────────────────────

export async function alertCopyTradeExecuted(params: {
  traderName: string;
  market: string;
  side: "YES" | "NO";
  price: number;
  amount: number;
  exchange: string;
  paperMode: boolean;
}): Promise<boolean> {
  const mode = params.paperMode ? "📄 PAPER" : "💰 LIVE";
  const sideEmoji = params.side === "YES" ? "🟢" : "🔴";
  const text = `🔔 *Copy Trade Executed* ${mode}

${sideEmoji} *${params.side}* on ${params.exchange}
📋 Market: ${params.market}
💵 Price: $${params.price.toFixed(3)}
💰 Amount: $${params.amount.toFixed(2)}
👤 Copied from: @${params.traderName}

_Trade executed automatically at flat $5 size_`;
  return sendMessage(text);
}

export async function alertStrategyOpportunity(params: {
  strategy: string;
  market: string;
  signal: string;
  edge: number;
  price: number;
  noaaProb: number;
}): Promise<boolean> {
  const text = `📊 *Strategy Opportunity Found*

🎯 Strategy: ${params.strategy}
📋 Market: ${params.market}
⚡ Signal: ${params.signal}
📈 Edge: ${(params.edge * 100).toFixed(1)}%
💵 Current Price: $${params.price.toFixed(3)}
🌤 NOAA Probability: ${(params.noaaProb * 100).toFixed(0)}%

_Paper trading bot will execute this automatically_`;
  return sendMessage(text);
}

export async function alertArbitrageGap(params: {
  market: string;
  kalshiPrice: number;
  polymarketPrice: number;
  spread: number;
  profitEstimate: number;
}): Promise<boolean> {
  const text = `⚡ *Arbitrage Gap Detected!*

📋 Market: ${params.market}
🏦 Kalshi: $${params.kalshiPrice.toFixed(3)}
🏦 Polymarket: $${params.polymarketPrice.toFixed(3)}
📊 Spread: ${(params.spread * 100).toFixed(1)}¢
💰 Est. Profit (per $100): $${params.profitEstimate.toFixed(2)}

_Act quickly — these gaps close fast!_`;
  return sendMessage(text);
}

export async function alertPositionClosed(params: {
  market: string;
  side: "YES" | "NO";
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  paperMode: boolean;
}): Promise<boolean> {
  const mode = params.paperMode ? "📄 PAPER" : "💰 LIVE";
  const pnlEmoji = params.pnl >= 0 ? "✅" : "❌";
  const pnlSign = params.pnl >= 0 ? "+" : "";
  const text = `${pnlEmoji} *Position Closed* ${mode}

📋 Market: ${params.market}
📌 Side: ${params.side}
📥 Entry: $${params.entryPrice.toFixed(3)}
📤 Exit: $${params.exitPrice.toFixed(3)}
💰 P&L: ${pnlSign}$${params.pnl.toFixed(2)}`;
  return sendMessage(text);
}

export async function alertBotStatus(message: string): Promise<boolean> {
  const text = `🤖 *Bot Status Update*\n\n${message}`;
  return sendMessage(text);
}

// ─── Aliases used by routers.ts ─────────────────────────────────────────────

/** Alias: send a raw text message (used by routers.ts) */
export async function sendTelegramMessage(text: string): Promise<boolean> {
  return sendMessage(text, "HTML");
}

/** Alias: test the connection (used by routers.ts) */
export async function testTelegramConnection(): Promise<boolean> {
  return testAlert();
}

/** Alias: alert a strategy opportunity (used by routers.ts) */
export async function alertOpportunity(params: {
  strategyName: string;
  market: string;
  signal: string;
  price: number;
  confidence: number;
  notes?: string;
}): Promise<boolean> {
  return alertStrategyOpportunity({
    strategy: params.strategyName,
    market: params.market,
    signal: params.signal,
    edge: params.confidence,
    price: params.price,
    noaaProb: params.confidence,
  });
}

export async function testAlert(): Promise<boolean> {
  const text = `✅ *Telegram Alerts Active!*

Your WeatherTrader bot is now connected and monitoring:
• 4 tracked traders
• Kalshi weather markets (8 cities)
• Cross-exchange arbitrage scanner
• Paper trading at flat $5/trade

All trades will be copied automatically and you'll be notified here instantly.`;
  return sendMessage(text);
}
