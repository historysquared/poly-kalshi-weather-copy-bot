/**
 * Kalshi Copy Trading Engine
 *
 * Strategy:
 *  - Scan every 30 seconds (not 2 minutes — speed matters)
 *  - Fetch BOTH active positions AND recent trades for each trader by wallet address
 *  - Map Polymarket weather markets → equivalent Kalshi markets
 *  - Execute flat $5 paper trades on every new signal
 *  - Slippage guard: skip if Kalshi ask is more than MAX_SLIPPAGE_PCT worse than original price
 *  - Deduplicate by transactionHash + conditionId to avoid double-fills
 */

import { getDb } from "./db";
import { trackedTraders, copyTrades, paperPositions } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { alertCopyTradeExecuted } from "./telegram";

// ─── Constants ────────────────────────────────────────────────────────────────
export const COPY_TRADE_AMOUNT = 5.00;          // Flat $5 per copy trade
export const MAX_SLIPPAGE_PCT  = 0.20;          // Skip if price is >20% worse than original
const SCAN_INTERVAL_MS         = 30_000;        // 30 second scan interval
const POLYMARKET_DATA_API      = "https://data-api.polymarket.com";
const KALSHI_API               = "https://api.elections.kalshi.com/trade-api/v2";
const TRADE_AGE_LIMIT_MS       = 5 * 60 * 1000; // Only copy trades from last 5 minutes

// ─── Market Mapping: Polymarket → Kalshi ─────────────────────────────────────
// Maps Polymarket weather market keywords to Kalshi ticker prefixes.
// Uses word-boundary regex to avoid substring collisions (e.g. "LA" inside "Dallas").
export const MARKET_MAPPING: Record<string, string> = {
  "NYC":           "KXHIGHNY",
  "New York":      "KXHIGHNY",
  "Chicago":       "KXHIGHCHI",
  "Los Angeles":   "KXHIGHLAX",
  "LA":            "KXHIGHLAX",
  "Dallas":        "KXHIGHDAL",
  "Miami":         "KXHIGHMIAMI",
  "Atlanta":       "KXHIGHATLANTA",
  "Seattle":       "KXHIGHSEATTLE",
  "Boston":        "KXHIGHBOSTON",
};

// ─── Polymarket API: Active Positions by Wallet Address ──────────────────────
/**
 * Fetches ALL current open positions for a trader using their wallet address.
 * Uses the Polymarket Data API: GET /positions?user=0x...
 * Returns rich data: avgPrice, curPrice, cashPnl, title, outcome, etc.
 */
export async function fetchPolymarketPositions(walletAddress: string): Promise<any[]> {
  try {
    const url = `${POLYMARKET_DATA_API}/positions?user=${walletAddress}&sizeThreshold=0.01&limit=500&sortBy=TOKENS&sortDirection=DESC`;
    const res = await fetch(url, { headers: { "Accept": "application/json" } });
    if (!res.ok) {
      console.warn(`[CopyTrader] Positions fetch failed for ${walletAddress}: ${res.status}`);
      return [];
    }
    const data = await res.json() as any[];
    return Array.isArray(data) ? data : [];
  } catch (err) {
    console.error(`[CopyTrader] Error fetching positions for ${walletAddress}:`, err);
    return [];
  }
}

// ─── Polymarket API: Closed Positions by Wallet Address ──────────────────────
/**
 * Fetches closed/redeemed positions for a trader.
 * Uses the Polymarket Data API: GET /positions?user=0x...&redeemable=true
 */
export async function fetchPolymarketClosedPositions(walletAddress: string): Promise<any[]> {
  try {
    const url = `${POLYMARKET_DATA_API}/positions?user=${walletAddress}&redeemable=true&limit=200&sortBy=TOKENS&sortDirection=DESC`;
    const res = await fetch(url, { headers: { "Accept": "application/json" } });
    if (!res.ok) return [];
    const data = await res.json() as any[];
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

// ─── Polymarket API: Recent Trades by Wallet Address ─────────────────────────
/**
 * Fetches recent trades (fills) for a trader using the CLOB Data API.
 * GET /trades?user=0x...&limit=50&takerOnly=false
 * Returns: proxyWallet, side, asset, conditionId, size, price, timestamp, title, outcome, transactionHash
 */
export async function fetchPolymarketTrades(walletAddress: string): Promise<any[]> {
  try {
    const url = `${POLYMARKET_DATA_API}/trades?user=${walletAddress}&limit=50&takerOnly=false`;
    const res = await fetch(url, { headers: { "Accept": "application/json" } });
    if (!res.ok) {
      console.warn(`[CopyTrader] Trades fetch failed for ${walletAddress}: ${res.status}`);
      return [];
    }
    const data = await res.json() as any[];
    return Array.isArray(data) ? data : [];
  } catch (err) {
    console.error(`[CopyTrader] Error fetching trades for ${walletAddress}:`, err);
    return [];
  }
}

// ─── Slippage Guard ───────────────────────────────────────────────────────────
/**
 * Returns true if the Kalshi ask price is acceptable relative to the original trade price.
 * Skips the copy trade if the Kalshi price is more than MAX_SLIPPAGE_PCT worse.
 *
 * For a YES buy: kalshiAsk should not be much higher than originalPrice
 * For a NO buy:  kalshiAsk should not be much higher than (1 - originalPrice)
 */
export function isWithinSlippage(
  originalPrice: number,
  kalshiAsk: number,
  side: "yes" | "no",
  maxSlippagePct: number = MAX_SLIPPAGE_PCT
): boolean {
  if (originalPrice <= 0 || kalshiAsk <= 0) return true; // Can't evaluate, allow
  const referencePrice = side === "yes" ? originalPrice : 1 - originalPrice;
  if (referencePrice <= 0) return true;
  const slippage = (kalshiAsk - referencePrice) / referencePrice;
  return slippage <= maxSlippagePct;
}

// ─── Find Equivalent Kalshi Market ───────────────────────────────────────────
/**
 * Given a Polymarket market title and side, finds the best matching open Kalshi market.
 * Returns the Kalshi ticker, side, and current ask price.
 */
export async function findKalshiEquivalent(
  marketTitle: string,
  side: "YES" | "NO" | string
): Promise<{ ticker: string; kalshiSide: "yes" | "no"; price: number } | null> {
  try {
    // Find city using word-boundary regex to avoid substring collisions
    let seriesTicker = "";
    for (const [keyword, ticker] of Object.entries(MARKET_MAPPING)) {
      const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const pattern = new RegExp(`\\b${escaped}\\b`, "i");
      if (pattern.test(marketTitle)) {
        seriesTicker = ticker;
        break;
      }
    }
    if (!seriesTicker) return null;

    // Fetch active Kalshi markets for this series
    const res = await fetch(
      `${KALSHI_API}/markets?series_ticker=${seriesTicker}&status=open&limit=20`,
      { headers: { "Accept": "application/json" } }
    );
    if (!res.ok) return null;
    const data = await res.json() as any;
    const markets: any[] = data?.markets || [];
    if (markets.length === 0) return null;

    // Pick the most liquid market (highest volume)
    const best = markets.sort((a, b) => (b.volume || 0) - (a.volume || 0))[0];
    const kalshiSide = side.toUpperCase() === "YES" ? "yes" : "no";
    const price = kalshiSide === "yes"
      ? parseFloat(best.yes_ask_dollars || best.yes_ask || "0.5")
      : parseFloat(best.no_ask_dollars || best.no_ask || "0.5");

    return { ticker: best.ticker, kalshiSide, price };
  } catch {
    return null;
  }
}

// ─── Execute Paper Trade on Kalshi ───────────────────────────────────────────
async function executePaperCopyTrade(params: {
  traderId: number;
  traderName: string;
  originalMarket: string;
  originalSide: string;
  originalPrice: number;
  kalshiTicker: string;
  kalshiSide: "yes" | "no";
  price: number;
  slippagePct: number;
}): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    const shares = COPY_TRADE_AMOUNT / params.price;

    await db.insert(copyTrades).values({
      traderId: params.traderId,
      traderName: params.traderName,
      originalMarket: params.originalMarket,
      originalSide: params.originalSide,
      kalshiTicker: params.kalshiTicker,
      kalshiSide: params.kalshiSide,
      price: params.price.toString(),
      amount: COPY_TRADE_AMOUNT.toString(),
      shares: shares.toString(),
      status: "open",
      paperMode: true,
    });

    await db.insert(paperPositions).values({
      market: `[COPY @${params.traderName}] ${params.kalshiTicker}`,
      outcome: params.kalshiSide.toUpperCase(),
      shares: shares.toString(),
      price: params.price.toString(),
      totalCost: COPY_TRADE_AMOUNT.toString(),
      status: "open",
      notes: `Copied from @${params.traderName} | Original: ${params.originalMarket} | Slippage: ${(params.slippagePct * 100).toFixed(1)}%`,
    });

    await alertCopyTradeExecuted({
      traderName: params.traderName,
      market: params.kalshiTicker,
      side: params.kalshiSide.toUpperCase() as "YES" | "NO",
      price: params.price,
      amount: COPY_TRADE_AMOUNT,
      exchange: "Kalshi (Paper)",
      paperMode: true,
    });

    console.log(
      `[CopyTrader] ✅ Paper trade: @${params.traderName} → ${params.kalshiTicker} ` +
      `${params.kalshiSide.toUpperCase()} $${COPY_TRADE_AMOUNT} ` +
      `(orig $${params.originalPrice.toFixed(3)} → kalshi $${params.price.toFixed(3)}, ` +
      `slippage ${(params.slippagePct * 100).toFixed(1)}%)`
    );
    return true;
  } catch (err) {
    console.error("[CopyTrader] Failed to execute paper trade:", err);
    return false;
  }
}

// ─── In-Memory Deduplication ──────────────────────────────────────────────────
// Keyed by trader username → Set of "conditionId:transactionHash" strings
const seenTradeKeys = new Map<string, Set<string>>();

function getTradeKey(trade: any): string {
  // Use transactionHash as primary key, fall back to conditionId+size+timestamp
  return trade.transactionHash
    || `${trade.conditionId}:${trade.size}:${trade.timestamp}`;
}

// ─── Main Copy Trading Cycle ──────────────────────────────────────────────────
export async function runCopyTradingCycle(): Promise<{
  checked: number;
  copied: number;
  skippedSlippage: number;
  errors: string[];
}> {
  const db = await getDb();
  if (!db) return { checked: 0, copied: 0, skippedSlippage: 0, errors: ["Database not available"] };

  const result = { checked: 0, copied: 0, skippedSlippage: 0, errors: [] as string[] };

  try {
    const traders = await db
      .select()
      .from(trackedTraders)
      .where(eq(trackedTraders.isActive, true));

    result.checked = traders.length;

    for (const trader of traders) {
      try {
        if (!seenTradeKeys.has(trader.username)) {
          seenTradeKeys.set(trader.username, new Set());
        }
        const seen = seenTradeKeys.get(trader.username)!;

        // Use wallet address if available, fall back to profile URL parsing
        const address = trader.walletAddress || extractAddressFromUrl(trader.profileUrl);
        if (!address) {
          console.log(`[CopyTrader] No wallet address for @${trader.username}, skipping`);
          continue;
        }

        // ── Fetch recent trades (primary signal source) ──────────────────────
        const recentTrades = await fetchPolymarketTrades(address);
        const now = Date.now();

        for (const trade of recentTrades) {
          const key = getTradeKey(trade);
          if (seen.has(key)) continue;

          // Only act on fresh trades
          const tradeTs = trade.timestamp
            ? (trade.timestamp > 1e12 ? trade.timestamp : trade.timestamp * 1000)
            : null;
          if (tradeTs && now - tradeTs > TRADE_AGE_LIMIT_MS) {
            seen.add(key); // Mark old trades as seen so we don't re-check them
            continue;
          }

          seen.add(key);

          // Only copy BUY trades (not sells/redemptions)
          if (trade.side && trade.side.toUpperCase() !== "BUY") continue;

          const marketTitle = trade.title || trade.market || "";
          const side = trade.outcome?.toUpperCase() === "NO" ? "NO" : "YES";
          const originalPrice = parseFloat(trade.price) || 0;

          const kalshiMarket = await findKalshiEquivalent(marketTitle, side);
          if (!kalshiMarket) {
            console.log(`[CopyTrader] No Kalshi equivalent for: ${marketTitle}`);
            continue;
          }

          // ── Slippage Guard ────────────────────────────────────────────────
          const referencePrice = side === "YES" ? originalPrice : 1 - originalPrice;
          const slippagePct = referencePrice > 0
            ? (kalshiMarket.price - referencePrice) / referencePrice
            : 0;

          if (!isWithinSlippage(originalPrice, kalshiMarket.price, kalshiMarket.kalshiSide)) {
            console.log(
              `[CopyTrader] ⚠️ Slippage too high for @${trader.username}: ` +
              `orig $${originalPrice.toFixed(3)} → kalshi $${kalshiMarket.price.toFixed(3)} ` +
              `(${(slippagePct * 100).toFixed(1)}% > ${MAX_SLIPPAGE_PCT * 100}%)`
            );
            result.skippedSlippage++;
            continue;
          }

          const success = await executePaperCopyTrade({
            traderId: trader.id,
            traderName: trader.username,
            originalMarket: marketTitle,
            originalSide: side,
            originalPrice,
            kalshiTicker: kalshiMarket.ticker,
            kalshiSide: kalshiMarket.kalshiSide,
            price: kalshiMarket.price,
            slippagePct,
          });

          if (success) result.copied++;
        }

        // Update lastCheckedAt
        await db
          .update(trackedTraders)
          .set({ lastCheckedAt: new Date() })
          .where(eq(trackedTraders.id, trader.id));

      } catch (err) {
        const msg = `Error processing @${trader.username}: ${err}`;
        console.error("[CopyTrader]", msg);
        result.errors.push(msg);
      }
    }
  } catch (err) {
    result.errors.push(`Database error: ${err}`);
  }

  return result;
}

// ─── Get Copy Trade History ───────────────────────────────────────────────────
export async function getCopyTradeHistory(limit = 50): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db
      .select()
      .from(copyTrades)
      .orderBy(desc(copyTrades.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}

// ─── Get Full Trader Profile (positions + trades) ─────────────────────────────
/**
 * Returns a combined view of a trader's active positions and recent trades
 * from Polymarket, keyed by their wallet address.
 */
export async function getTraderProfile(walletAddress: string): Promise<{
  activePositions: any[];
  closedPositions: any[];
  recentTrades: any[];
}> {
  const [activePositions, closedPositions, recentTrades] = await Promise.all([
    fetchPolymarketPositions(walletAddress),
    fetchPolymarketClosedPositions(walletAddress),
    fetchPolymarketTrades(walletAddress),
  ]);
  return { activePositions, closedPositions, recentTrades };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
/**
 * Attempts to extract a 0x wallet address from a Polymarket profile URL.
 * e.g. "https://polymarket.com/profile/0xabc123..." → "0xabc123..."
 */
function extractAddressFromUrl(url: string): string | null {
  if (!url) return null;
  const match = url.match(/0x[a-fA-F0-9]{40}/);
  return match ? match[0] : null;
}

export { SCAN_INTERVAL_MS };
