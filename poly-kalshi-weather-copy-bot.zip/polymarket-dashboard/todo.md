# Polymarket Dashboard TODO

## Phase 1: Backend API for Data Access
- [x] Fix TypeScript errors in Home.tsx
- [x] Create backend API endpoint to read paper trading data
- [x] Create tRPC router for portfolio data
- [x] Test API endpoint

## Phase 2: Real-time Data Integration
- [x] Connect frontend to backend API
- [x] Implement auto-refresh for live data
- [x] Add loading states and error handling
- [x] Test with actual paper trading data files
- [x] Display tracked traders (@neobrother and others) on dashboard
- [x] Show their recent trades in real-time

## Phase 3: Notification System
- [x] Research Discord webhook API (free option)
- [x] Create notification service in backend
- [x] Add configuration for Discord webhook URL
- [x] Implement trader activity alerts
- [x] Implement strategy opportunity alerts
- [x] Test notification system

## Phase 4: Database Migration & Persistence
- [x] Design database schema for trades, positions, and traders
- [x] Migrate portfolio data from JSON to database
- [x] Migrate tracked traders data to database
- [x] Create database queries and helpers

## Phase 5: Backend Bot Services
- [x] Create scheduled job for bot execution
- [x] Implement Polymarket data fetching service
- [x] Implement NOAA weather data service
- [x] Create trading strategy execution service
- [x] Add Discord notification integration

## Phase 6: Admin Panel & Settings
- [x] Create settings page for Discord webhook
- [x] Add trader management UI (add/remove traders)
- [x] Build bot control panel (start/stop/configure)
- [x] Add trading history view

## Phase 7: Deployment
- [x] Test all features end-to-end
- [x] Save checkpoint for deployment
- [ ] Publish website permanently
- [ ] Verify bot runs automatically

## Phase 8: Final Integration
- [x] Add @neobrother and successful traders to database
- [x] Add @gopfan2 and other top weather traders
- [x] Configure Discord webhook for notifications
- [x] Update Python bot to connect to MySQL database
- [x] Test bot writing positions to database
- [x] Verify live updates appear on dashboard
- [ ] Save final checkpoint

## Phase 9: Automated Bot Execution
- [x] Create Node.js service to execute Python bot
- [x] Implement scheduled job (every 2 minutes)
- [x] Add bot control API endpoints (start/stop/status)
- [x] Test automated execution and database writes
- [x] Verify real-time dashboard updates
- [ ] Save final checkpoint with automation

## Phase 10: Show Trader Activity
- [x] Fetch real trades from tracked traders via Polymarket API
- [x] Display their actual positions and trades on dashboard
- [x] Show what they're buying/selling in real-time
- [x] Add trade history timeline for each trader

## Phase 11: Live Trades Tab
- [x] Add trader k9Q2mX4L8A7ZP3R to database
- [x] Create "Live Trades" tab in dashboard
- [x] Display real-time positions from tracked traders
- [x] Show buy/sell activity with timestamps
- [x] Add filtering and sorting options
- [ ] Save checkpoint

## Phase 12: Kalshi Port
- [x] Research Kalshi API endpoints and authentication
- [x] Research Kalshi weather market structure
- [x] Build Kalshi API client (Python)
- [x] Port neobrother strategy to Kalshi
- [x] Port weather arbitrage strategy to Kalshi
- [x] Port paper trading engine to Kalshi
- [x] Build cross-exchange arbitrage scanner (Kalshi vs Polymarket)
- [x] Update dashboard with Kalshi tab
- [x] Add Kalshi positions and trades to Live Trades page
- [x] Add arbitrage opportunities alert panel
- [x] Test all Kalshi integrations
- [ ] Save checkpoint and deploy

## Phase 13: Fix Kalshi Price Data
- [x] Diagnose why YES BID/ASK and NO BID/ASK prices show as dashes
- [x] Fix Kalshi API endpoint to return orderbook data
- [x] Fix frontend to correctly display price data
- [x] Verify volume data is loading
- [ ] Save checkpoint and deploy fix

## Phase 14: Telegram Alerts + Kalshi Copy Trading

### Telegram Alerts
- [x] Create Telegram bot via BotFather and configure webhook
- [x] Add Telegram bot token to dashboard secrets
- [x] Build server-side Telegram notification service
- [x] Alert types: new trade opportunity, copy trade executed, position closed, arbitrage gap found
- [x] Add Telegram chat ID configuration to Settings page
- [x] Test alert delivery end-to-end

### Kalshi Copy Trading Engine
- [x] Build trader activity poller (scan Polymarket + Kalshi traders every 30s)
- [x] Map Polymarket weather market → equivalent Kalshi market (word-boundary regex fix applied)
- [x] Build Kalshi order execution module (paper mode)
- [x] Set flat $5 per trade on all copy trades (no variable sizing)
- [x] Copy ALL trades automatically (no filters, take everything)
- [x] Store copy trade history in database (copy_trades table)
- [x] Show copy trades on dashboard with Copy Trades tab
- [x] Send Telegram alert on every copy trade executed

### Dashboard Updates
- [x] Add Telegram settings panel with test button
- [x] Add copy trading controls (manual scan, config summary)
- [x] Add Copy Trades tab to main dashboard
- [x] Save checkpoint and deploy

## Phase 15: Copy Trading Improvements

- [x] Reduce scan interval from 120s to 30s
- [x] Fetch full active + closed trades by trader wallet address from Polymarket Data API
- [x] fetchPolymarketPositions() - active positions via GET /positions?user=0x...
- [x] fetchPolymarketClosedPositions() - closed positions via GET /positions?user=0x...&redeemable=true
- [x] fetchPolymarketTrades() - recent trades via GET /trades?user=0x...
- [x] getTraderProfile() - combines all three in parallel for full trader view
- [x] walletAddress column added to trackedTraders schema (migration applied)
- [x] Add slippage guard: skip copy trade if Kalshi ask >20% worse than original price
- [x] isWithinSlippage() exported and fully tested with YES/NO side logic
- [x] Settings page updated: 30s interval, slippage guard explanation, 4-stat grid
- [x] 37 tests in copyTrader.test.ts, 54 total across 5 files — all passing
- [x] Save checkpoint

## Phase 16: Fix Market Display + Trade Detection

- [ ] Diagnose why only NYC markets show in Kalshi Markets tab
- [ ] Fix Kalshi market fetching to show all 8 city series
- [ ] Diagnose why no copy trades are being detected from HFT accounts
- [ ] Fix Polymarket trade detection: check API endpoints, address format, response parsing
- [ ] Add debug logging to show raw API responses during scan cycle
- [ ] Verify tracked trader wallet addresses are correct 0x format
- [ ] Test with real HFT account addresses
- [ ] Save checkpoint
