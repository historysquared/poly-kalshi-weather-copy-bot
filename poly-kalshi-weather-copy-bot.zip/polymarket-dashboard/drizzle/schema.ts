import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Trading positions (open and closed)
 */
export const positions = mysqlTable("positions", {
  id: int("id").autoincrement().primaryKey(),
  tradeId: varchar("tradeId", { length: 64 }).notNull().unique(),
  marketId: varchar("marketId", { length: 128 }).notNull(),
  marketQuestion: text("marketQuestion").notNull(),
  outcome: varchar("outcome", { length: 256 }).notNull(),
  shares: decimal("shares", { precision: 18, scale: 8 }).notNull(),
  entryPrice: decimal("entryPrice", { precision: 18, scale: 8 }).notNull(),
  exitPrice: decimal("exitPrice", { precision: 18, scale: 8 }),
  totalCost: decimal("totalCost", { precision: 18, scale: 2 }).notNull(),
  strategyName: varchar("strategyName", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
  pnl: decimal("pnl", { precision: 18, scale: 2 }),
  roi: decimal("roi", { precision: 10, scale: 2 }),
  notes: text("notes"),
  openedAt: timestamp("openedAt").defaultNow().notNull(),
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Position = typeof positions.$inferSelect;
export type InsertPosition = typeof positions.$inferInsert;

/**
 * Tracked traders for copy trading
 */
export const trackedTraders = mysqlTable("trackedTraders", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 128 }).notNull().unique(),
  profileUrl: varchar("profileUrl", { length: 512 }).notNull(),
  /** Polymarket wallet address (0x...) for direct API lookups */
  walletAddress: varchar("walletAddress", { length: 64 }),
  focus: varchar("focus", { length: 256 }),
  notes: text("notes"),
  isActive: boolean("isActive").default(true).notNull(),
  addedAt: timestamp("addedAt").defaultNow().notNull(),
  lastCheckedAt: timestamp("lastCheckedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TrackedTrader = typeof trackedTraders.$inferSelect;
export type InsertTrackedTrader = typeof trackedTraders.$inferInsert;

/**
 * Trader activity log
 */
export const traderTrades = mysqlTable("traderTrades", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull(),
  tradeData: json("tradeData").notNull(),
  detectedAt: timestamp("detectedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TraderTrade = typeof traderTrades.$inferSelect;
export type InsertTraderTrade = typeof traderTrades.$inferInsert;

/**
 * System settings and configuration
 */
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 128 }).notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;

/**
 * Bot execution log
 */
export const botLogs = mysqlTable("botLogs", {
  id: int("id").autoincrement().primaryKey(),
  logType: mysqlEnum("logType", ["scan", "trade", "error", "notification"]).notNull(),
  message: text("message").notNull(),
  data: json("data"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BotLog = typeof botLogs.$inferSelect;
export type InsertBotLog = typeof botLogs.$inferInsert;

/**
 * Copy trades — mirror trades executed on Kalshi from tracked trader activity
 */
export const copyTrades = mysqlTable("copyTrades", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull(),
  traderName: varchar("traderName", { length: 128 }).notNull(),
  originalMarket: text("originalMarket").notNull(),
  originalSide: varchar("originalSide", { length: 8 }).notNull(),
  kalshiTicker: varchar("kalshiTicker", { length: 128 }).notNull(),
  kalshiSide: mysqlEnum("kalshiSide", ["yes", "no"]).notNull(),
  price: decimal("price", { precision: 10, scale: 4 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  shares: decimal("shares", { precision: 18, scale: 6 }).notNull(),
  status: mysqlEnum("status", ["open", "closed", "cancelled"]).default("open").notNull(),
  paperMode: boolean("paperMode").default(true).notNull(),
  pnl: decimal("pnl", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CopyTrade = typeof copyTrades.$inferSelect;
export type InsertCopyTrade = typeof copyTrades.$inferInsert;

/**
 * Paper positions — virtual positions for paper trading
 */
export const paperPositions = mysqlTable("paperPositions", {
  id: int("id").autoincrement().primaryKey(),
  strategy: varchar("strategy", { length: 64 }).notNull().default("manual"),
  market: text("market").notNull(),
  outcome: varchar("outcome", { length: 16 }).notNull(),
  shares: decimal("shares", { precision: 18, scale: 6 }).notNull(),
  price: decimal("price", { precision: 10, scale: 4 }).notNull(),
  totalCost: decimal("totalCost", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
  pnl: decimal("pnl", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaperPosition = typeof paperPositions.$inferSelect;
export type InsertPaperPosition = typeof paperPositions.$inferInsert;