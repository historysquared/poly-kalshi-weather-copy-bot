CREATE TABLE `copyTrades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`traderId` int NOT NULL,
	`traderName` varchar(128) NOT NULL,
	`originalMarket` text NOT NULL,
	`originalSide` varchar(8) NOT NULL,
	`kalshiTicker` varchar(128) NOT NULL,
	`kalshiSide` enum('yes','no') NOT NULL,
	`price` decimal(10,4) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`shares` decimal(18,6) NOT NULL,
	`status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
	`paperMode` boolean NOT NULL DEFAULT true,
	`pnl` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `copyTrades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paperPositions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`strategy` varchar(64) NOT NULL DEFAULT 'manual',
	`market` text NOT NULL,
	`outcome` varchar(16) NOT NULL,
	`shares` decimal(18,6) NOT NULL,
	`price` decimal(10,4) NOT NULL,
	`totalCost` decimal(10,2) NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`pnl` decimal(10,2),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paperPositions_id` PRIMARY KEY(`id`)
);
