CREATE TABLE `botLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`logType` enum('scan','trade','error','notification') NOT NULL,
	`message` text NOT NULL,
	`data` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `botLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `positions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tradeId` varchar(64) NOT NULL,
	`marketId` varchar(128) NOT NULL,
	`marketQuestion` text NOT NULL,
	`outcome` varchar(256) NOT NULL,
	`shares` decimal(18,8) NOT NULL,
	`entryPrice` decimal(18,8) NOT NULL,
	`exitPrice` decimal(18,8),
	`totalCost` decimal(18,2) NOT NULL,
	`strategyName` varchar(64) NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`pnl` decimal(18,2),
	`roi` decimal(10,2),
	`notes` text,
	`openedAt` timestamp NOT NULL DEFAULT (now()),
	`closedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `positions_id` PRIMARY KEY(`id`),
	CONSTRAINT `positions_tradeId_unique` UNIQUE(`tradeId`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(128) NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `trackedTraders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(128) NOT NULL,
	`profileUrl` varchar(512) NOT NULL,
	`focus` varchar(256),
	`notes` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`addedAt` timestamp NOT NULL DEFAULT (now()),
	`lastCheckedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trackedTraders_id` PRIMARY KEY(`id`),
	CONSTRAINT `trackedTraders_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `traderTrades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`traderId` int NOT NULL,
	`tradeData` json NOT NULL,
	`detectedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `traderTrades_id` PRIMARY KEY(`id`)
);
