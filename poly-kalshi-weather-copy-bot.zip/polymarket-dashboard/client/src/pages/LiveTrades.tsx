import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight, Activity, Clock } from "lucide-react";

interface TraderTrade {
  id: number;
  trader: string;
  market: string;
  outcome: string;
  side: 'BUY' | 'SELL';
  price: number;
  size: number;
  timestamp: string;
}

export default function LiveTrades() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  
  // Fetch all trader trades
  const { data: allTrades, refetch } = trpc.trading.getAllTraderTrades.useQuery(undefined, {
    refetchInterval: autoRefresh ? 30000 : false, // Refresh every 30 seconds
  });

  const trades: TraderTrade[] = allTrades || [];

  // Format timestamp
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold font-mono tracking-tight">Live Trader Activity</h1>
            <p className="text-gray-400 mt-1">Real-time positions from tracked traders</p>
          </div>
          <div className="flex items-center gap-2">
            <Activity className={`w-4 h-4 ${autoRefresh ? 'text-green-500 animate-pulse' : 'text-gray-500'}`} />
            <span className="text-sm text-gray-400 font-mono">
              {autoRefresh ? 'LIVE' : 'PAUSED'}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono text-gray-400">Total Trades</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono">{trades.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono text-gray-400">Buy Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-green-500">
              {trades.filter(t => t.side === 'BUY').length}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono text-gray-400">Sell Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-red-500">
              {trades.filter(t => t.side === 'SELL').length}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono text-gray-400">Active Traders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono">
              {new Set(trades.map(t => t.trader)).size}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Trades Feed */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="font-mono">Recent Trades</CardTitle>
            <button
              onClick={() => refetch()}
              className="text-sm text-blue-400 hover:text-blue-300 font-mono"
            >
              Refresh
            </button>
          </div>
        </CardHeader>
        <CardContent>
          {trades.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="font-mono">No trades detected yet</p>
              <p className="text-sm mt-2">Waiting for tracked traders to make moves...</p>
            </div>
          ) : (
            <div className="space-y-3">
              {trades.slice(0, 50).map((trade) => (
                <div
                  key={trade.id}
                  className="flex items-start gap-4 p-4 bg-zinc-800/50 rounded-lg border border-zinc-700 hover:border-zinc-600 transition-colors"
                >
                  {/* Side Indicator */}
                  <div className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center ${
                    trade.side === 'BUY' ? 'bg-green-500/10' : 'bg-red-500/10'
                  }`}>
                    {trade.side === 'BUY' ? (
                      <ArrowUpRight className="w-6 h-6 text-green-500" />
                    ) : (
                      <ArrowDownRight className="w-6 h-6 text-red-500" />
                    )}
                  </div>

                  {/* Trade Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="font-mono text-xs">
                        {trade.trader}
                      </Badge>
                      <Badge 
                        variant={trade.side === 'BUY' ? 'default' : 'destructive'}
                        className="font-mono text-xs"
                      >
                        {trade.side}
                      </Badge>
                    </div>
                    
                    <p className="text-sm font-medium mb-1 truncate">
                      {trade.market}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-gray-400 font-mono">
                      <span>Outcome: {trade.outcome}</span>
                      <span>Price: ${trade.price.toFixed(2)}</span>
                      <span>Size: {trade.size.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Timestamp */}
                  <div className="flex-shrink-0 text-right">
                    <div className="flex items-center gap-1 text-xs text-gray-500 font-mono">
                      <Clock className="w-3 h-3" />
                      {formatTime(trade.timestamp)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
