/**
 * Polymarket Weather Trading Dashboard
 * Design: Financial Terminal Modernism - Dark theme with data density and real-time updates
 */

import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, TrendingUp, DollarSign, Target, BarChart3, Users, Copy, Settings } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface PortfolioData {
  starting_capital: number;
  current_capital: number;
  total_invested: number;
  total_pnl: number;
  open_positions: any[];
  closed_positions: any[];
  win_count: number;
  loss_count: number;
  total_trades: number;
}

interface TrackedTrader {
  username: string;
  profile_url: string;
  focus: string;
  notes: string;
  recent_trades?: any[];
}

export default function Home() {
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Fetch portfolio data from backend
  const { data: portfolio, isLoading: portfolioLoading } =
    trpc.trading.getPortfolio.useQuery(undefined, { refetchInterval: 30000 });

  // Fetch tracked traders data
  const { data: traders, isLoading: tradersLoading } =
    trpc.trading.getTrackedTraders.useQuery(undefined, { refetchInterval: 30000 });

  // Fetch copy trade history
  const { data: copyTrades, isLoading: copyTradesLoading } =
    trpc.copyTrading.getHistory.useQuery({ limit: 50 }, { refetchInterval: 30000 });

  // Fetch bot status
  const { data: botStatus } = trpc.bot.status.useQuery(undefined, { refetchInterval: 15000 });

  // Update timestamp when data changes
  useEffect(() => {
    if (portfolio || traders) setLastUpdate(new Date());
  }, [portfolio, traders]);

  if (portfolioLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Activity className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-destructive">Failed to load portfolio data</p>
      </div>
    );
  }

  const openPositionsValue = portfolio.open_positions.reduce((sum: number, pos: any) => sum + pos.total_cost, 0);
  const totalValue = portfolio.current_capital + openPositionsValue;
  const roi = ((totalValue - portfolio.starting_capital) / portfolio.starting_capital * 100);
  const winRate = portfolio.total_trades > 0
    ? (portfolio.win_count / (portfolio.win_count + portfolio.loss_count) * 100) || 0
    : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-3">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold tracking-tight">Polymarket Trading Dashboard</h1>
              <p className="text-xs text-muted-foreground">Weather Markets Paper Trading System</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap justify-end">
              <Link href="/live-trades">
                <Button variant="default" size="sm" className="bg-blue-600 hover:bg-blue-700">
                  Live Trades
                </Button>
              </Link>
              <Link href="/kalshi">
                <Button variant="default" size="sm" className="bg-[#4a9eff] hover:bg-[#3a8eef] text-white">
                  Kalshi Markets
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-1" />
                  Settings
                </Button>
              </Link>
              <div className="flex items-center gap-2 ml-2">
                <div className={`w-2 h-2 rounded-full ${botStatus?.isRunning ? "bg-green-400 animate-pulse" : "bg-gray-500"}`} />
                <Badge variant="outline" className="text-xs">
                  {botStatus?.isRunning ? "LIVE" : "IDLE"}
                </Badge>
                <span className="text-xs text-muted-foreground font-mono hidden sm:block">
                  {lastUpdate.toLocaleTimeString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container py-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="stat-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <DollarSign className="w-3 h-3" /> Portfolio Value
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="data-value text-2xl">${totalValue.toFixed(2)}</div>
              <p className={`text-xs mt-1 ${roi >= 0 ? 'positive' : 'negative'}`}>
                {roi >= 0 ? '+' : ''}{roi.toFixed(2)}% ROI
              </p>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Total P&L
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`data-value text-2xl ${portfolio.total_pnl >= 0 ? 'positive' : 'negative'}`}>
                ${portfolio.total_pnl.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {portfolio.closed_positions.length} settled trades
              </p>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <Target className="w-3 h-3" /> Win Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="data-value text-2xl">{winRate.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {portfolio.win_count}W / {portfolio.loss_count}L
              </p>
            </CardContent>
          </Card>

          <Card className="stat-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <BarChart3 className="w-3 h-3" /> Active Trades
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="data-value text-2xl">{portfolio.open_positions.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                ${openPositionsValue.toFixed(2)} deployed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="positions" className="space-y-4">
          <TabsList>
            <TabsTrigger value="positions">My Positions</TabsTrigger>
            <TabsTrigger value="copy">
              <Copy className="w-3 h-3 mr-1" />
              Copy Trades
              {copyTrades && copyTrades.length > 0 && (
                <Badge className="ml-2 bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs px-1.5 py-0">
                  {copyTrades.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="traders">
              <Users className="w-3 h-3 mr-1" />
              Tracked Traders
            </TabsTrigger>
          </TabsList>

          {/* My Open Positions Tab */}
          <TabsContent value="positions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  Open Positions
                </CardTitle>
              </CardHeader>
              <CardContent>
                {portfolio.open_positions.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No open positions</p>
                ) : (
                  <div className="space-y-4">
                    {portfolio.open_positions.map((position: any) => (
                      <div
                        key={position.trade_id}
                        className="border border-border rounded-lg p-4 hover:border-primary/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{position.outcome}</h3>
                            <p className="text-sm text-muted-foreground">{position.market_question}</p>
                          </div>
                          <Badge variant="outline">{position.strategy_name?.replace('_', ' ')}</Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 mt-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Entry Price</p>
                            <p className="font-mono font-semibold">${position.price.toFixed(4)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Shares</p>
                            <p className="font-mono font-semibold">{position.shares.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Total Cost</p>
                            <p className="font-mono font-semibold">${position.total_cost.toFixed(2)}</p>
                          </div>
                        </div>
                        {position.notes && (
                          <div className="mt-3 pt-3 border-t border-border">
                            <p className="text-xs text-muted-foreground">{position.notes}</p>
                          </div>
                        )}
                        <div className="mt-2 text-xs text-muted-foreground font-mono">
                          Opened: {new Date(position.timestamp).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Copy Trades Tab */}
          <TabsContent value="copy" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Copy className="w-5 h-5 text-purple-400" />
                  Copy Trade History
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-xs">Paper Mode</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {copyTradesLoading ? (
                  <p className="text-center text-muted-foreground py-8">Loading copy trades...</p>
                ) : !copyTrades || copyTrades.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <Copy className="w-10 h-10 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground">No copy trades yet</p>
                    <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                      The bot will automatically copy trades from @neobrother, @gopfan2, @weatherpro, and k9Q2mX4L8A7ZP3R when they open new weather market positions on Polymarket.
                    </p>
                    <Link href="/settings">
                      <Button variant="outline" size="sm" className="mt-2">
                        Run Manual Scan →
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {copyTrades.map((trade: any) => (
                      <div
                        key={trade.id}
                        className="border border-border rounded-lg p-4 hover:border-purple-500/30 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-sm">@{trade.traderName}</span>
                              <Badge
                                className={trade.kalshiSide === "yes"
                                  ? "bg-green-500/20 text-green-300 border-green-500/30 text-xs"
                                  : "bg-red-500/20 text-red-300 border-red-500/30 text-xs"}
                              >
                                {trade.kalshiSide?.toUpperCase()}
                              </Badge>
                              <Badge
                                className={trade.status === "open"
                                  ? "bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs"
                                  : "bg-gray-500/20 text-gray-300 border-gray-500/30 text-xs"}
                              >
                                {trade.status}
                              </Badge>
                              {trade.paperMode && (
                                <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-xs">
                                  paper
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1 truncate">
                              Original: {trade.originalMarket}
                            </p>
                          </div>
                          <div className="text-right shrink-0 ml-4">
                            <p className="font-mono font-semibold text-sm">${trade.amount?.toFixed(2)}</p>
                            {trade.pnl !== null && (
                              <p className={`text-xs font-mono ${trade.pnl >= 0 ? "text-green-400" : "text-red-400"}`}>
                                {trade.pnl >= 0 ? "+" : ""}${trade.pnl?.toFixed(2)}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-3 mt-3 text-xs">
                          <div>
                            <p className="text-muted-foreground">Kalshi Ticker</p>
                            <p className="font-mono">{trade.kalshiTicker}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Price</p>
                            <p className="font-mono">${trade.price?.toFixed(3)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Shares</p>
                            <p className="font-mono">{trade.shares?.toFixed(2)}</p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground font-mono mt-2">
                          {new Date(trade.createdAt).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tracked Traders Tab */}
          <TabsContent value="traders" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  Monitored Traders
                </CardTitle>
              </CardHeader>
              <CardContent>
                {tradersLoading ? (
                  <p className="text-center text-muted-foreground py-8">Loading traders...</p>
                ) : !traders || traders.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No traders being monitored</p>
                ) : (
                  <div className="space-y-4">
                    {traders.map((trader: TrackedTrader) => (
                      <div key={trader.username} className="border border-border rounded-lg p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="font-semibold">@{trader.username}</h3>
                            {trader.notes && <p className="text-sm text-muted-foreground mt-0.5">{trader.notes}</p>}
                            {trader.focus && <Badge variant="outline" className="mt-2 text-xs">{trader.focus}</Badge>}
                          </div>
                          <a
                            href={trader.profile_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-primary hover:underline shrink-0"
                          >
                            View Profile →
                          </a>
                        </div>

                        {trader.recent_trades && trader.recent_trades.length > 0 && (
                          <div className="mt-3 pt-3 border-t border-border">
                            <h4 className="text-xs font-semibold mb-2 text-muted-foreground uppercase tracking-wide">
                              Recent Activity
                            </h4>
                            <div className="space-y-1.5">
                              {trader.recent_trades.slice(0, 3).map((trade: any, idx: number) => (
                                <div key={idx} className="text-xs bg-accent/40 rounded px-3 py-2 flex justify-between items-center">
                                  <span className="text-muted-foreground truncate">{trade.market}</span>
                                  <Badge variant="secondary" className="text-xs ml-2 shrink-0">{trade.type}</Badge>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* System Status */}
        <Card className="mt-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground text-xs">Strategies</p>
                <p className="font-semibold text-sm">neobrother, arbitrage</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Monitored Traders</p>
                <p className="font-semibold text-sm">{traders?.length || 0} active</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Copy Trades</p>
                <p className="font-semibold text-sm">{copyTrades?.length || 0} total</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Status</p>
                <Badge className={botStatus?.isRunning
                  ? "bg-green-500/20 text-green-400 border-green-500/50"
                  : "bg-gray-500/20 text-gray-400 border-gray-500/50"
                }>
                  {botStatus?.isRunning ? "● Running" : "● Idle"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
