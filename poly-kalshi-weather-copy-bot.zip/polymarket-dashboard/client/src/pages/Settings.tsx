import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Bell, Users, Bot, Trash2, Plus, ArrowLeft, Send, CheckCircle2, XCircle, RefreshCw, Copy } from "lucide-react";
import { useLocation } from "wouter";

export default function Settings() {
  const [, navigate] = useLocation();
  const [newTraderUsername, setNewTraderUsername] = useState("");
  const [newTraderFocus, setNewTraderFocus] = useState("");
  const [newTraderNotes, setNewTraderNotes] = useState("");

  // Fetch settings
  const { data: botSettings, refetch: refetchBot } = trpc.settings.getBotSettings.useQuery();
  const { data: traders, refetch: refetchTraders } = trpc.trading.getTrackedTraders.useQuery();
  const { data: telegramSettings } = trpc.telegram.getSettings.useQuery();
  const { data: botStatus, refetch: refetchBotStatus } = trpc.bot.status.useQuery();

  // Mutations
  const updateBotSettings = trpc.settings.updateBotSettings.useMutation({
    onSuccess: () => {
      toast.success("Bot settings updated");
      refetchBot();
    },
    onError: (error) => toast.error(`Failed: ${error.message}`),
  });

  const addTrader = trpc.trading.addTrader.useMutation({
    onSuccess: () => {
      toast.success("Trader added successfully");
      setNewTraderUsername("");
      setNewTraderFocus("");
      setNewTraderNotes("");
      refetchTraders();
    },
    onError: (error) => toast.error(`Failed to add trader: ${error.message}`),
  });

  const removeTrader = trpc.trading.removeTrader.useMutation({
    onSuccess: () => {
      toast.success("Trader removed");
      refetchTraders();
    },
    onError: (error) => toast.error(`Failed: ${error.message}`),
  });

  const testTelegram = trpc.telegram.test.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success("✅ Telegram alert sent! Check your phone.");
      } else {
        toast.error("❌ " + data.message);
      }
    },
    onError: (error) => toast.error(`Telegram error: ${error.message}`),
  });

  const startBot = trpc.bot.start.useMutation({
    onSuccess: () => {
      toast.success("Bot started — scanning every 30 seconds");
      refetchBotStatus();
    },
    onError: (error) => toast.error(`Failed to start bot: ${error.message}`),
  });

  const stopBot = trpc.bot.stop.useMutation({
    onSuccess: () => {
      toast.success("Bot stopped");
      refetchBotStatus();
    },
    onError: (error) => toast.error(`Failed to stop bot: ${error.message}`),
  });

  const runCopyTradeCycle = trpc.copyTrading.runCycle.useMutation({
    onSuccess: (data) => {
      toast.success(`Cycle complete: checked ${data.checked} traders, copied ${data.copied} trades`);
    },
    onError: (error) => toast.error(`Cycle error: ${error.message}`),
  });

  const handleAddTrader = () => {
    if (!newTraderUsername) {
      toast.error("Please enter a username");
      return;
    }
    addTrader.mutate({
      username: newTraderUsername,
      profileUrl: `https://polymarket.com/@${newTraderUsername}`,
      focus: newTraderFocus || undefined,
      notes: newTraderNotes || undefined,
    });
  };

  const handleRemoveTrader = (username: string) => {
    if (confirm(`Stop tracking @${username}?`)) {
      removeTrader.mutate({ username });
    }
  };

  const isRunning = botStatus?.isRunning ?? botSettings?.is_running ?? false;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
            <p className="text-sm text-muted-foreground">Configure your trading bot and notifications</p>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <Tabs defaultValue="telegram" className="space-y-4">
          <TabsList className="grid grid-cols-4 w-full max-w-xl">
            <TabsTrigger value="telegram">
              <Send className="w-4 h-4 mr-2" />
              Telegram
            </TabsTrigger>
            <TabsTrigger value="copy">
              <Copy className="w-4 h-4 mr-2" />
              Copy Trading
            </TabsTrigger>
            <TabsTrigger value="traders">
              <Users className="w-4 h-4 mr-2" />
              Traders
            </TabsTrigger>
            <TabsTrigger value="bot">
              <Bot className="w-4 h-4 mr-2" />
              Bot
            </TabsTrigger>
          </TabsList>

          {/* ── Telegram Tab ── */}
          <TabsContent value="telegram">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="w-5 h-5 text-blue-400" />
                    Telegram Alerts
                  </CardTitle>
                  <CardDescription>
                    Real-time trade notifications sent directly to your Telegram account
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Connection status */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      {telegramSettings?.configured ? (
                        <CheckCircle2 className="w-5 h-5 text-green-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400" />
                      )}
                      <div>
                        <p className="font-medium">
                          {telegramSettings?.configured ? "Connected" : "Not configured"}
                        </p>
                        {telegramSettings?.configured && (
                          <p className="text-sm text-muted-foreground">
                            Bot: {telegramSettings.botName} · Chat: {telegramSettings.chatId}
                          </p>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => testTelegram.mutate()}
                      disabled={testTelegram.isPending}
                      variant="outline"
                      className="gap-2"
                    >
                      {testTelegram.isPending ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      {testTelegram.isPending ? "Sending..." : "Send Test Alert"}
                    </Button>
                  </div>

                  {/* What you'll receive */}
                  <div className="p-4 bg-accent/30 rounded-lg space-y-3">
                    <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">
                      Alert Types
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">📝</span>
                        <span>Paper copy trades executed</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">📊</span>
                        <span>Strategy signals found</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">⚡</span>
                        <span>Arbitrage gaps detected</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">✅</span>
                        <span>Positions closed with P&L</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-sm text-blue-300">
                    <strong>Note:</strong> Credentials are stored securely as environment variables.
                    Your bot is <strong>@WeatherTrader1_bot</strong> and alerts go to your personal chat.
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ── Copy Trading Tab ── */}
          <TabsContent value="copy">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Copy className="w-5 h-5 text-purple-400" />
                    Copy Trading Engine
                  </CardTitle>
                  <CardDescription>
                    Monitors tracked Polymarket traders and mirrors their positions on Kalshi at flat $5 per trade
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Config summary */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-3 bg-accent/30 rounded-lg text-center">
                      <p className="text-2xl font-bold text-green-400">$5.00</p>
                      <p className="text-xs text-muted-foreground mt-1">Per Trade (flat)</p>
                    </div>
                    <div className="p-3 bg-accent/30 rounded-lg text-center">
                      <p className="text-2xl font-bold text-blue-400">{traders?.length ?? 4}</p>
                      <p className="text-xs text-muted-foreground mt-1">Tracked Traders</p>
                    </div>
                    <div className="p-3 bg-accent/30 rounded-lg text-center">
                      <p className="text-2xl font-bold text-orange-400">20%</p>
                      <p className="text-xs text-muted-foreground mt-1">Max Slippage</p>
                    </div>
                    <div className="p-3 bg-accent/30 rounded-lg text-center">
                      <p className="text-2xl font-bold text-yellow-400">Paper</p>
                      <p className="text-xs text-muted-foreground mt-1">Trading Mode</p>
                    </div>
                  </div>

                  {/* Manual trigger */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h4 className="font-semibold">Manual Scan</h4>
                      <p className="text-sm text-muted-foreground">
                        Check all tracked traders for new positions right now
                      </p>
                    </div>
                    <Button
                      onClick={() => runCopyTradeCycle.mutate()}
                      disabled={runCopyTradeCycle.isPending}
                      variant="outline"
                      className="gap-2"
                    >
                      {runCopyTradeCycle.isPending ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <RefreshCw className="w-4 h-4" />
                      )}
                      {runCopyTradeCycle.isPending ? "Scanning..." : "Run Scan Now"}
                    </Button>
                  </div>

                  {/* How it works */}
                  <div className="p-4 bg-accent/30 rounded-lg space-y-3">
                    <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">
                      How It Works
                    </h4>
                    <ol className="text-sm space-y-2 text-muted-foreground list-decimal list-inside">
                      <li>Every <strong className="text-foreground">30 seconds</strong>, bot fetches all recent trades AND active positions for each tracked trader by their Polymarket wallet address</li>
                      <li>Detects BUY trades in weather markets (NYC, Chicago, LA, Dallas, Miami, Atlanta, Seattle, Boston) — takes ALL trades, no filters</li>
                      <li>Finds the equivalent open Kalshi binary weather market (e.g. KXHIGHNY-25MAR18-T50) by city keyword</li>
                      <li><strong className="text-foreground">Slippage guard:</strong> if the current Kalshi ask is more than 20% worse than the original price, the trade is skipped to avoid getting filled at a terrible price</li>
                      <li>Executes a paper $5 trade on the same side (YES/NO) — flat sizing, no variable amounts</li>
                      <li>Sends a Telegram alert with trader name, ticker, side, price, and slippage %</li>
                    </ol>
                  </div>

                  {/* Slippage explanation */}
                  <div className="p-4 border border-orange-500/20 bg-orange-500/5 rounded-lg space-y-2">
                    <h4 className="font-semibold text-sm text-orange-300 flex items-center gap-2">
                      <span>⚡</span> Slippage Guard — Why It Matters
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      When a trader buys YES at $0.12 on Polymarket, we look for the same market on Kalshi. 
                      If the Kalshi YES ask is $0.18 (50% higher), that's too much slippage — we'd be copying 
                      at a much worse price than the original trader got. The 20% limit means if the original 
                      was $0.12, we'll only copy if Kalshi is ≤ $0.144.
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Skipped trades are logged in the console. Adjust this threshold if you want to be more/less aggressive.
                    </p>
                  </div>

                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-sm text-yellow-300">
                    <strong>Paper Mode Active:</strong> All copy trades are simulated. Add your Kalshi API key to enable live trading.
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ── Tracked Traders Tab ── */}
          <TabsContent value="traders">
            <Card className="mb-4">
              <CardHeader>
                <CardTitle>Add Trader to Monitor</CardTitle>
                <CardDescription>Track successful Polymarket traders and copy their weather market positions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Polymarket Username</Label>
                    <Input
                      id="username"
                      placeholder="neobrother"
                      value={newTraderUsername}
                      onChange={(e) => setNewTraderUsername(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="focus">Focus (Optional)</Label>
                      <Input
                        id="focus"
                        placeholder="Weather markets"
                        value={newTraderFocus}
                        onChange={(e) => setNewTraderFocus(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="notes">Notes (Optional)</Label>
                      <Input
                        id="notes"
                        placeholder="High-frequency, $4,923 from $100"
                        value={newTraderNotes}
                        onChange={(e) => setNewTraderNotes(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button onClick={handleAddTrader} disabled={addTrader.isPending} className="w-fit">
                    <Plus className="w-4 h-4 mr-2" />
                    {addTrader.isPending ? "Adding..." : "Add Trader"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monitored Traders</CardTitle>
                <CardDescription>Currently tracking {traders?.length ?? 0} traders</CardDescription>
              </CardHeader>
              <CardContent>
                {!traders || traders.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No traders being monitored</p>
                ) : (
                  <div className="space-y-3">
                    {traders.map((trader) => (
                      <div
                        key={trader.username}
                        className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-accent/20 transition-colors"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold">@{trader.username}</h3>
                            {trader.focus && <Badge variant="outline" className="text-xs">{trader.focus}</Badge>}
                          </div>
                          {trader.notes && (
                            <p className="text-sm text-muted-foreground">{trader.notes}</p>
                          )}
                          <a
                            href={trader.profile_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-primary hover:underline mt-1 inline-block"
                          >
                            View Polymarket Profile →
                          </a>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveTrader(trader.username)}
                          disabled={removeTrader.isPending}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Bot Settings Tab ── */}
          <TabsContent value="bot">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  Bot Control
                </CardTitle>
                <CardDescription>Start/stop the automated trading scanner</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status + toggle */}
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${isRunning ? "bg-green-400 animate-pulse" : "bg-gray-500"}`} />
                    <div>
                      <h4 className="font-semibold">{isRunning ? "Bot Running" : "Bot Stopped"}</h4>
                      <p className="text-sm text-muted-foreground">
                        {isRunning
                          ? `Scanning every 30s · Last run: ${botStatus?.lastRun ? new Date(botStatus.lastRun).toLocaleTimeString() : "never"}`
                          : "Click Start to begin automated scanning (30s interval)"}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant={isRunning ? "destructive" : "default"}
                    onClick={() => isRunning ? stopBot.mutate() : startBot.mutate({ intervalSeconds: 30 })}
                    disabled={startBot.isPending || stopBot.isPending}
                  >
                    {startBot.isPending || stopBot.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : null}
                    {isRunning ? "Stop Bot" : "Start Bot"}
                  </Button>
                </div>

                  {/* Scan interval */}
                  <div className="space-y-2">
                    <Label htmlFor="scanInterval">Scan Interval (seconds)</Label>
                    <Input
                      id="scanInterval"
                      type="number"
                      min="10"
                      max="3600"
                      defaultValue={botSettings?.scan_interval ?? 30}
                      onBlur={(e) => {
                        const value = parseInt(e.target.value);
                        if (value >= 10) updateBotSettings.mutate({ scanInterval: value });
                      }}
                    />
                    <p className="text-xs text-muted-foreground">
                      How often the bot checks for new opportunities. Default: 30 seconds. Lower = faster copy but more API calls.
                    </p>
                  </div>

                {/* Active strategies */}
                <div className="p-4 bg-accent/30 rounded-lg">
                  <h4 className="font-semibold mb-3 text-sm uppercase tracking-wide text-muted-foreground">
                    Active Strategies
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-start gap-3 text-sm">
                      <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 shrink-0">Strategy 1</Badge>
                      <span><strong>@neobrother HF</strong> — Buy YES at 5–15¢, NO at 40–55¢ on high-temp markets</span>
                    </div>
                    <div className="flex items-start gap-3 text-sm">
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30 shrink-0">Strategy 2</Badge>
                      <span><strong>NOAA Arbitrage</strong> — Compare Kalshi prices to NOAA 7-day forecasts for edge</span>
                    </div>
                    <div className="flex items-start gap-3 text-sm">
                      <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 shrink-0">Strategy 3</Badge>
                      <span><strong>Copy Trading</strong> — Mirror positions from 4 tracked Polymarket traders on Kalshi</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
