import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, RefreshCw, AlertTriangle, BarChart3, Zap, DollarSign } from "lucide-react";
import { Link } from "wouter";

const CITIES = [
  { id: "NYC", name: "New York" },
  { id: "Chicago", name: "Chicago" },
  { id: "LA", name: "Los Angeles" },
  { id: "Dallas", name: "Dallas" },
  { id: "Boston", name: "Boston" },
  { id: "Atlanta", name: "Atlanta" },
];

export default function KalshiMarkets() {
  const [selectedCity, setSelectedCity] = useState("NYC");

  const { data: marketsData, isLoading: marketsLoading, refetch: refetchMarkets } =
    trpc.kalshi.getWeatherMarkets.useQuery({ city: selectedCity }, { refetchInterval: 30000 });

  const { data: arbitrageData, isLoading: arbitrageLoading, refetch: refetchArbitrage } =
    trpc.arbitrage.getLatestOpportunities.useQuery(undefined, { refetchInterval: 60000 });

  const { data: kalshiPortfolio } =
    trpc.arbitrage.getKalshiPortfolio.useQuery(undefined, { refetchInterval: 30000 });

  const handleRefresh = () => {
    refetchMarkets();
    refetchArbitrage();
  };

  const markets = marketsData?.markets || [];
  const opportunities = arbitrageData?.opportunities || [];
  const highConfidenceOpps = opportunities.filter((o: any) => o.confidence === "high");

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white font-mono">
      {/* Header */}
      <header className="border-b border-[#1e2d4a] bg-[#0d1220] px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-[#4a9eff] hover:text-white">
                ← Dashboard
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-[#4a9eff]" />
              <h1 className="text-xl font-bold text-white tracking-wider">KALSHI WEATHER MARKETS</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {opportunities.length > 0 && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 animate-pulse">
                {opportunities.length} ARBI OPP{opportunities.length !== 1 ? "S" : ""}
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              className="border-[#1e2d4a] text-[#4a9eff] hover:bg-[#1e2d4a]"
            >
              <RefreshCw className="w-4 h-4 mr-1" />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">

        {/* Kalshi Portfolio Summary */}
        {kalshiPortfolio && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-[#0d1220] border-[#1e2d4a]">
              <CardContent className="p-4">
                <div className="text-xs text-[#6b8cba] mb-1">KALSHI CAPITAL</div>
                <div className="text-2xl font-bold text-white">
                  ${(kalshiPortfolio.current_capital || 1000).toFixed(2)}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1220] border-[#1e2d4a]">
              <CardContent className="p-4">
                <div className="text-xs text-[#6b8cba] mb-1">KALSHI P&L</div>
                <div className={`text-2xl font-bold ${(kalshiPortfolio.total_pnl || 0) >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {(kalshiPortfolio.total_pnl || 0) >= 0 ? "+" : ""}${(kalshiPortfolio.total_pnl || 0).toFixed(4)}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1220] border-[#1e2d4a]">
              <CardContent className="p-4">
                <div className="text-xs text-[#6b8cba] mb-1">OPEN POSITIONS</div>
                <div className="text-2xl font-bold text-[#4a9eff]">
                  {(kalshiPortfolio.open_positions || []).length}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#0d1220] border-[#1e2d4a]">
              <CardContent className="p-4">
                <div className="text-xs text-[#6b8cba] mb-1">TOTAL TRADES</div>
                <div className="text-2xl font-bold text-white">
                  {kalshiPortfolio.total_trades || 0}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Arbitrage Opportunities */}
        <Card className="bg-[#0d1220] border-[#1e2d4a]">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-[#4a9eff] text-sm tracking-wider flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                CROSS-EXCHANGE ARBITRAGE (KALSHI vs POLYMARKET)
              </CardTitle>
              {arbitrageData?.scan_time && (
                <span className="text-xs text-[#4a6b8a]">
                  Last scan: {new Date(arbitrageData.scan_time).toLocaleTimeString()}
                </span>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {arbitrageLoading ? (
              <div className="text-center py-8 text-[#4a6b8a]">Scanning for opportunities...</div>
            ) : opportunities.length === 0 ? (
              <div className="text-center py-8">
                <AlertTriangle className="w-8 h-8 text-yellow-500/50 mx-auto mb-2" />
                <p className="text-[#4a6b8a] text-sm">No arbitrage opportunities found at current prices.</p>
                <p className="text-[#4a6b8a] text-xs mt-1">Markets are efficiently priced. Opportunities emerge during volatility.</p>
                <p className="text-[#4a6b8a] text-xs mt-1">Run the Python scanner: <code className="text-[#4a9eff]">python3 ~/kalshi_bot/strategy/cross_exchange_arbitrage.py</code></p>
              </div>
            ) : (
              <div className="space-y-3">
                {opportunities.map((opp: any, i: number) => (
                  <div key={i} className="border border-[#1e2d4a] rounded-lg p-4 hover:border-[#4a9eff]/50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className={opp.confidence === "high" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"}>
                          {opp.confidence?.toUpperCase()}
                        </Badge>
                        <span className="text-white font-semibold text-sm">{opp.city}</span>
                        <span className="text-[#4a6b8a] text-xs">{opp.strategy}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-green-400 font-bold">+${opp.edge?.toFixed(4)}</div>
                        <div className="text-xs text-[#4a6b8a]">edge per $1</div>
                      </div>
                    </div>
                    {opp.type === "cross_exchange" && (
                      <div className="grid grid-cols-2 gap-3 mt-2 text-xs">
                        <div className="bg-[#0a0e1a] rounded p-2">
                          <div className="text-[#4a9eff] font-semibold mb-1">KALSHI</div>
                          <div className="text-white">{opp.kalshi?.action?.toUpperCase()} @ ${opp.kalshi?.price?.toFixed(3)}</div>
                          <div className="text-[#4a6b8a] truncate">{opp.kalshi?.ticker}</div>
                        </div>
                        <div className="bg-[#0a0e1a] rounded p-2">
                          <div className="text-purple-400 font-semibold mb-1">POLYMARKET</div>
                          <div className="text-white">{opp.polymarket?.action?.toUpperCase()} @ ${opp.polymarket?.price?.toFixed(3)}</div>
                          <div className="text-[#4a6b8a] truncate">{opp.polymarket?.title?.slice(0, 40)}...</div>
                        </div>
                      </div>
                    )}
                    {opp.type === "kalshi_internal" && (
                      <div className="mt-2 text-xs bg-[#0a0e1a] rounded p-2">
                        <div className="text-[#4a9eff] font-semibold mb-1">KALSHI INTERNAL</div>
                        <div className="text-white">Buy BOTH YES (${opp.yes_ask?.toFixed(3)}) + NO (${opp.no_ask?.toFixed(3)}) = ${opp.total_cost?.toFixed(3)}</div>
                        <div className="text-[#4a6b8a] truncate">{opp.ticker}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Live Kalshi Markets */}
        <Card className="bg-[#0d1220] border-[#1e2d4a]">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-[#4a9eff] text-sm tracking-wider flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                LIVE KALSHI WEATHER MARKETS
              </CardTitle>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs text-[#4a6b8a]">Live</span>
              </div>
            </div>
            {/* City Selector */}
            <div className="flex gap-2 flex-wrap mt-3">
              {CITIES.map(city => (
                <button
                  key={city.id}
                  onClick={() => setSelectedCity(city.id)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                    selectedCity === city.id
                      ? "bg-[#4a9eff] text-white"
                      : "bg-[#1e2d4a] text-[#6b8cba] hover:bg-[#2a3d5a]"
                  }`}
                >
                  {city.name}
                </button>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            {marketsLoading ? (
              <div className="text-center py-8 text-[#4a6b8a]">Loading markets...</div>
            ) : markets.length === 0 ? (
              <div className="text-center py-8 text-[#4a6b8a]">
                No open markets for {selectedCity}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-[#4a6b8a] border-b border-[#1e2d4a]">
                      <th className="text-left py-2 pr-4">MARKET</th>
                      <th className="text-right py-2 px-3">YES BID</th>
                      <th className="text-right py-2 px-3">YES ASK</th>
                      <th className="text-right py-2 px-3">NO BID</th>
                      <th className="text-right py-2 px-3">NO ASK</th>
                      <th className="text-right py-2 px-3">VOLUME</th>
                      <th className="text-right py-2 pl-3">SIGNAL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {markets.map((market: any) => {
                      const yesAsk = market.yes_ask;
                      const noAsk = market.no_ask;
                      const isUnderpriced = yesAsk !== null && yesAsk < 0.15;
                      const isNoUnderpriced = noAsk !== null && noAsk < 0.15;
                      const hasArbi = yesAsk !== null && noAsk !== null && (yesAsk + noAsk) < 0.97;

                      return (
                        <tr key={market.ticker} className="border-b border-[#1e2d4a]/50 hover:bg-[#1e2d4a]/30 transition-colors">
                          <td className="py-2 pr-4">
                            <div className="text-white truncate max-w-[280px]" title={market.title}>
                              {market.title?.replace(/\*\*/g, "")}
                            </div>
                            <div className="text-[#4a6b8a] text-[10px]">{market.ticker}</div>
                          </td>
                          <td className="text-right py-2 px-3 text-[#6b8cba]">
                            {market.yes_bid !== null ? `$${market.yes_bid.toFixed(3)}` : "—"}
                          </td>
                          <td className={`text-right py-2 px-3 font-semibold ${isUnderpriced ? "text-green-400" : "text-white"}`}>
                            {yesAsk !== null ? `$${yesAsk.toFixed(3)}` : "—"}
                          </td>
                          <td className="text-right py-2 px-3 text-[#6b8cba]">
                            {market.no_bid !== null ? `$${market.no_bid.toFixed(3)}` : "—"}
                          </td>
                          <td className={`text-right py-2 px-3 font-semibold ${isNoUnderpriced ? "text-green-400" : "text-white"}`}>
                            {noAsk !== null ? `$${noAsk.toFixed(3)}` : "—"}
                          </td>
                          <td className="text-right py-2 px-3 text-[#6b8cba]">
                            {market.volume?.toLocaleString() || "0"}
                          </td>
                          <td className="text-right py-2 pl-3">
                            {hasArbi ? (
                              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px]">
                                ARBI
                              </Badge>
                            ) : isUnderpriced ? (
                              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-[10px]">
                                <TrendingUp className="w-2 h-2 mr-1" />
                                BUY YES
                              </Badge>
                            ) : isNoUnderpriced ? (
                              <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-[10px]">
                                <TrendingDown className="w-2 h-2 mr-1" />
                                BUY NO
                              </Badge>
                            ) : (
                              <span className="text-[#4a6b8a]">—</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

      </main>
    </div>
  );
}
