-- Add successful weather traders to the database
INSERT INTO tracked_traders (username, profile_url, focus, notes, is_active, added_at) VALUES
('neobrother', 'https://polymarket.com/@neobrother', 'Weather markets', 'High-frequency weather trader, made $4,923 from $100. Strategy: Buy YES at 5-15¢, NO at 40-55¢. Max $1 per position.', true, NOW()),
('gopfan2', 'https://polymarket.com/@gopfan2', 'Weather markets', 'Made $2M+ on weather trading. Focus on temperature predictions and weather arbitrage.', true, NOW()),
('weatherpro', 'https://polymarket.com/@weatherpro', 'Weather & Climate', 'Specializes in NOAA forecast arbitrage. Consistent profits from mispriced temperature buckets.', true, NOW())
ON DUPLICATE KEY UPDATE 
  profile_url = VALUES(profile_url),
  focus = VALUES(focus),
  notes = VALUES(notes),
  is_active = VALUES(is_active);
